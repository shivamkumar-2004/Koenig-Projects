const EVENTS_URL = "data/events.json";
const STORAGE_KEY_REGISTRATIONS = "campusEvents.registrations";
const STORAGE_KEY_PREFERRED_CATEGORY = "campusEvents.preferredCategory";

let allEvents = [];
let selectedCategory = "all";
let searchTerm = "";
let sortMode = "date-asc";
let selectedEventId = null;
let registrations = [];

const eventsGrid = document.getElementById("eventsGrid");
const eventsStatus = document.getElementById("eventsStatus");
const categoryFilters = document.getElementById("categoryFilters");
const categoryList = document.getElementById("categoryList");
const searchInput = document.getElementById("searchInput");
const sortSelect = document.getElementById("sortSelect");
const eventDetailsSection = document.getElementById("eventDetails");
const eventDetailsBody = document.getElementById("eventDetailsBody");
const closeDetailsBtn = document.getElementById("closeDetails");
const eventSelectField = document.getElementById("eventSelect");
const registrationForm = document.getElementById("registrationForm");
const participantsBody = document.getElementById("participantsBody");
const participantsStatus = document.getElementById("participantsStatus");
const notificationEl = document.getElementById("notification");
const navToggle = document.getElementById("navToggle");
const primaryNav = document.getElementById("primaryNav");

function formatDate(isoDate) {
    const date = new Date(`${isoDate}T00:00:00`);
    return date.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function showNotification(message, type = "success") {
    notificationEl.textContent = message;
    notificationEl.dataset.type = type;
    notificationEl.hidden = false;
    window.clearTimeout(showNotification.timeoutId);
    showNotification.timeoutId = window.setTimeout(() => {
        notificationEl.hidden = true;
    }, 4000);
}

async function loadEvents() {
    eventsStatus.textContent = "Loading events…";
    eventsStatus.dataset.state = "loading";

    try {
        const response = await fetch(EVENTS_URL);
        if (!response.ok) {
            throw new Error(`Server responded with status ${response.status}`);
        }

        const data = await response.json();
        if (!Array.isArray(data)) {
            throw new Error("Unexpected event data format received from the server.");
        }

        allEvents = data.map((event) => ({
            ...event,
            dateObj: new Date(`${event.date}T${event.time || "00:00"}`)
        }));

        eventsStatus.textContent = `${allEvents.length} events loaded.`;
        eventsStatus.dataset.state = "loaded";

        buildCategoryFilters();
        buildCategoryList();
        buildEventSelectOptions();
        applyPreferredCategory();
        renderEvents();
    } catch (error) {
        eventsStatus.textContent = `Could not load events (${error.message}).`;
        eventsStatus.dataset.state = "error";
        showNotification("We couldn't load the event list. Please try again.", "error");
        renderRetryControl();
    }
}

function renderRetryControl() {
    const retryBtn = document.createElement("button");
    retryBtn.type = "button";
    retryBtn.className = "btn btn-ghost btn-small";
    retryBtn.textContent = "Retry";
    retryBtn.addEventListener("click", () => {
        retryBtn.remove();
        loadEvents();
    });
    eventsStatus.appendChild(document.createTextNode(" "));
    eventsStatus.appendChild(retryBtn);
}

function getCategories() {
    const categories = allEvents.map((event) => event.category);
    return [...new Set(categories)].sort();
}

function buildCategoryFilters() {
    const categories = getCategories();
    categoryFilters.querySelectorAll("[data-category]:not([data-category='all'])").forEach((chip) => chip.remove());

    categories.forEach((category) => {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = "chip";
        chip.dataset.category = category;
        chip.textContent = category;
        categoryFilters.appendChild(chip);
    });
}

function buildCategoryList() {
    categoryList.innerHTML = "";
    getCategories().forEach((category) => {
        const count = allEvents.filter((event) => event.category === category).length;
        const li = document.createElement("li");
        li.textContent = `${category} (${count})`;
        categoryList.appendChild(li);
    });
}

function buildEventSelectOptions() {
    const currentValue = eventSelectField.value;
    eventSelectField.querySelectorAll("option:not(:first-child)").forEach((opt) => opt.remove());

    [...allEvents]
        .sort((a, b) => a.dateObj - b.dateObj)
        .forEach((event) => {
            const option = document.createElement("option");
            option.value = event.id;
            option.textContent = `${event.name} — ${formatDate(event.date)}`;
            eventSelectField.appendChild(option);
        });

    if (currentValue) eventSelectField.value = currentValue;
}

function applyPreferredCategory() {
    try {
        const stored = localStorage.getItem(STORAGE_KEY_PREFERRED_CATEGORY);
        if (stored && (stored === "all" || getCategories().includes(stored))) {
            selectedCategory = stored;
            categoryFilters.querySelectorAll("[data-category]").forEach((chip) => {
                chip.classList.toggle("is-active", chip.dataset.category === selectedCategory);
            });
        }
    } catch (error) {
        console.warn("Local storage unavailable for preferences:", error.message);
    }
}

function getFilteredSortedEvents() {
    const term = searchTerm.trim().toLowerCase();

    let result = allEvents.filter((event) => {
        const matchesCategory = selectedCategory === "all" || event.category === selectedCategory;
        const matchesSearch =
            term === "" ||
            event.name.toLowerCase().includes(term) ||
            event.venue.toLowerCase().includes(term);
        return matchesCategory && matchesSearch;
    });

    result = result.sort((a, b) => {
        switch (sortMode) {
            case "date-desc":
                return b.dateObj - a.dateObj;
            case "seats-desc":
                return b.seatsAvailable - a.seatsAvailable;
            case "name-asc":
                return a.name.localeCompare(b.name);
            default:
                return a.dateObj - b.dateObj;
        }
    });

    return result;
}

function renderEvents() {
    const events = getFilteredSortedEvents();
    eventsGrid.innerHTML = "";

    if (events.length === 0) {
        eventsStatus.textContent = "No events match your search or filter.";
        return;
    }

    const totalSeats = events.reduce((sum, event) => sum + event.seatsAvailable, 0);
    eventsStatus.textContent = `Showing ${events.length} event${events.length === 1 ? "" : "s"} — ${totalSeats} seats available in total.`;
    eventsStatus.dataset.state = "loaded";

    events.forEach((event) => {
        eventsGrid.appendChild(buildEventCard(event));
    });
}

const buildEventCard = (event) => {
    const card = document.createElement("article");
    card.className = "event-card";
    card.dataset.eventId = event.id;
    card.tabIndex = 0;

    const isLowSeats = event.seatsAvailable <= 20;

    card.innerHTML = `
        <span class="seats-badge" data-low="${isLowSeats}">${event.seatsAvailable} seats left</span>
        <img src="${event.image}" alt="${event.name}">
        <div class="event-card-body">
            <span class="category-tag">${event.category}</span>
            <h3>${event.name}</h3>
            <p class="meta">${formatDate(event.date)} · ${event.venue}</p>
        </div>
    `;

    card.addEventListener("click", () => showEventDetails(event.id));
    card.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            showEventDetails(event.id);
        }
    });

    return card;
};

function showEventDetails(eventId) {
    const event = allEvents.find((e) => e.id === eventId);
    if (!event) return;

    selectedEventId = eventId;
    eventDetailsBody.innerHTML = `
        <img src="${event.image}" alt="${event.name}">
        <h3>${event.name}</h3>
        <p>${event.description}</p>
        <dl>
            <dt>Category</dt><dd>${event.category}</dd>
            <dt>Date</dt><dd>${formatDate(event.date)}</dd>
            <dt>Time</dt><dd>${event.time}</dd>
            <dt>Venue</dt><dd>${event.venue}</dd>
            <dt>Seats available</dt><dd>${event.seatsAvailable}</dd>
        </dl>
    `;
    eventDetailsSection.hidden = false;
    eventDetailsSection.scrollIntoView({ behavior: "smooth", block: "start" });
    eventSelectField.value = event.id;
}

function checkSeatAvailability(eventId) {
    return new Promise((resolve, reject) => {
        window.setTimeout(() => {
            const event = allEvents.find((e) => e.id === eventId);
            if (!event) {
                reject(new Error("Selected event could not be found."));
                return;
            }
            if (event.seatsAvailable <= 0) {
                reject(new Error("This event is fully booked."));
                return;
            }
            resolve(event);
        }, 400);
    });
}

const VALIDATORS = {
    fullName: (value) => (value.trim().length >= 2 ? "" : "Enter your full name (at least 2 characters)."),
    email: (value) => (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) ? "" : "Enter a valid email address."),
    phone: (value) => (/^\d{10}$/.test(value.replace(/\D/g, "")) ? "" : "Enter a valid 10-digit phone number."),
    password: (value) =>
        /^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(value) ? "" : "Password needs 8+ characters with a letter and a number.",
    eventSelect: (value) => (value ? "" : "Select an event to register for."),
    dob: (value) => (value ? "" : "Date of birth is required."),
    yearOfStudy: (value) => (value ? "" : "Select your year of study."),
    consent: (checked) => (checked ? "" : "You must accept the terms to register.")
};

function clearFormErrors() {
    registrationForm.querySelectorAll(".field-error").forEach((el) => {
        el.textContent = "";
    });
}

function validateRegistrationForm(formValues) {
    const errors = {};

    Object.keys(VALIDATORS).forEach((field) => {
        const message = VALIDATORS[field](formValues[field]);
        if (message) errors[field] = message;
    });

    const alreadyRegistered = registrations.some(
        (reg) => reg.eventId === formValues.eventSelect && reg.email.toLowerCase() === formValues.email.toLowerCase()
    );
    if (alreadyRegistered) {
        errors.eventSelect = "You're already registered for this event with this email.";
    }

    return errors;
}

function displayFormErrors(errors) {
    Object.keys(errors).forEach((field) => {
        const errorEl = document.getElementById(`err-${field}`);
        if (errorEl) errorEl.textContent = errors[field];
    });
}

function readFormValues() {
    const formData = new FormData(registrationForm);
    return {
        fullName: formData.get("fullName") || "",
        email: formData.get("email") || "",
        phone: formData.get("phone") || "",
        password: formData.get("password") || "",
        eventSelect: formData.get("eventSelect") || "",
        dob: formData.get("dob") || "",
        yearOfStudy: formData.get("yearOfStudy") || "",
        dietary: formData.getAll("dietary"),
        notes: formData.get("notes") || "",
        consent: registrationForm.elements.consent.checked
    };
}

function loadStoredRegistrations() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY_REGISTRATIONS);
        registrations = raw ? JSON.parse(raw) : [];
        if (!Array.isArray(registrations)) throw new Error("Stored registration data was corrupted.");
    } catch (error) {
        console.warn("Could not read stored registrations, resetting:", error.message);
        registrations = [];
        try {
            localStorage.removeItem(STORAGE_KEY_REGISTRATIONS);
        } catch (cleanupError) {
            console.warn("Could not clear corrupted storage:", cleanupError.message);
        }
    }
    renderParticipantsTable();
}

function persistRegistrations() {
    try {
        if (registrations.length === 0) {
            localStorage.removeItem(STORAGE_KEY_REGISTRATIONS);
        } else {
            localStorage.setItem(STORAGE_KEY_REGISTRATIONS, JSON.stringify(registrations));
        }
    } catch (error) {
        showNotification("Your registration was saved for this session, but browser storage is unavailable.", "error");
    }
}

function renderParticipantsTable() {
    participantsBody.innerHTML = "";

    if (registrations.length === 0) {
        participantsStatus.textContent = "No registrations yet on this device.";
        return;
    }

    participantsStatus.textContent = `${registrations.length} registration${registrations.length === 1 ? "" : "s"} stored on this device.`;

    registrations.forEach((reg) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${reg.fullName}</td>
            <td>${reg.eventName}</td>
            <td>${reg.yearOfStudy}</td>
            <td>${new Date(reg.registeredAt).toLocaleString()}</td>
            <td><button type="button" class="remove-btn" data-id="${reg.id}">Remove</button></td>
        `;
        participantsBody.appendChild(row);
    });
}

function removeRegistration(id) {
    registrations = registrations.filter((reg) => reg.id !== id);
    persistRegistrations();
    renderParticipantsTable();
    showNotification("Registration removed.", "success");
}

async function handleRegistrationSubmit(event) {
    event.preventDefault();
    clearFormErrors();

    const values = readFormValues();
    const errors = validateRegistrationForm(values);

    if (Object.keys(errors).length > 0) {
        displayFormErrors(errors);
        showNotification("Please fix the highlighted fields.", "error");
        return;
    }

    const submitBtn = registrationForm.querySelector("button[type='submit']");
    submitBtn.disabled = true;
    submitBtn.textContent = "Checking availability…";

    try {
        const event_ = await checkSeatAvailability(values.eventSelect);

        const registration = {
            id: `REG-${Date.now()}`,
            fullName: values.fullName,
            email: values.email,
            phone: values.phone,
            eventId: event_.id,
            eventName: event_.name,
            yearOfStudy: values.yearOfStudy,
            dietary: values.dietary,
            notes: values.notes,
            registeredAt: new Date().toISOString()
        };

        registrations.push(registration);
        persistRegistrations();
        renderParticipantsTable();

        registrationForm.reset();
        clearFormErrors();
        showNotification(`You're registered for ${event_.name}.`, "success");
    } catch (error) {
        showNotification(error.message, "error");
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = "Register";
    }
}

function handleCategoryFilterClick(event) {
    const chip = event.target.closest("[data-category]");
    if (!chip) return;

    selectedCategory = chip.dataset.category;
    categoryFilters.querySelectorAll("[data-category]").forEach((c) => {
        c.classList.toggle("is-active", c === chip);
    });

    try {
        localStorage.setItem(STORAGE_KEY_PREFERRED_CATEGORY, selectedCategory);
    } catch (error) {
        console.warn("Could not save category preference:", error.message);
    }

    renderEvents();
}

function initEventListeners() {
    searchInput.addEventListener("input", (e) => {
        searchTerm = e.target.value;
        renderEvents();
    });

    sortSelect.addEventListener("change", (e) => {
        sortMode = e.target.value;
        renderEvents();
    });

    categoryFilters.addEventListener("click", handleCategoryFilterClick);

    closeDetailsBtn.addEventListener("click", () => {
        eventDetailsSection.hidden = true;
        selectedEventId = null;
    });

    registrationForm.addEventListener("submit", handleRegistrationSubmit);

    registrationForm.addEventListener("reset", () => {
        window.setTimeout(clearFormErrors, 0);
    });

    participantsBody.addEventListener("click", (e) => {
        const button = e.target.closest(".remove-btn");
        if (!button) return;
        removeRegistration(button.dataset.id);
    });

    navToggle.addEventListener("click", () => {
        const isOpen = primaryNav.classList.toggle("is-open");
        navToggle.setAttribute("aria-expanded", String(isOpen));
    });
}

function init() {
    initEventListeners();
    loadStoredRegistrations();
    loadEvents();
}

document.addEventListener("DOMContentLoaded", init);
