# Campus Events — Student Event Management Portal

## Files
- `index.html` — page structure
- `css/styles.css` — all styling
- `js/script.js` — application logic
- `data/events.json` — event data fetched at runtime
- `00_requirement_coverage.md` — maps every lab requirement to where it's implemented

## Running it
Browsers block `fetch()` on local files opened directly (`file://...`), so this needs to
be served over a local HTTP server rather than opened by double-clicking `index.html`.

Easiest options:
- **VS Code:** install the "Live Server" extension, right-click `index.html`, choose
  "Open with Live Server".
- **Node:** from this folder, run `npx serve` and open the printed local URL.
- **Python:** from this folder, run `python3 -m http.server 8000` and open
  `http://localhost:8000`.

## Notes
- Event images are placeholder photos from picsum.photos and the hero video is a public
  sample clip from MDN — both need an internet connection to load; everything else
  (search, filter, sort, form validation, Local Storage) works fully offline once the
  page and `events.json` have loaded once.
- Registrations are stored per-browser via Local Storage under the key
  `campusEvents.registrations`. Clearing site data will remove them.
