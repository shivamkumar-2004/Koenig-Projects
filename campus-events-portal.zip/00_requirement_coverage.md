# Requirement Coverage

## 1. HTML Structure
| Requirement | Where |
|---|---|
| Semantic elements: header, nav, main, section, article, aside, footer | `index.html` throughout |
| Navigation menu | `.primary-nav` in `<header>` |
| Hero/banner section | `.hero` |
| Upcoming events section | `#events` |
| Event categories | `#categories` (`<aside>`) |
| Event details | `#eventDetails` (`<article>`) |
| Registration section | `#register` |
| Registered participants section | `#participants` |
| Footer | `<footer class="site-footer">` |
| Ordered/unordered lists | `.category-list` (ul), `.primary-nav ul`, `.checkbox-group`/`.radio-group` labels |
| Tables | `#participantsTable` |
| Images | event card images, hero poster, details image |
| Audio or video | `<video class="hero-media">` in the hero |
| Hyperlinks | nav links, footer links, `mailto:` link |

## 2. Registration Form
| Control | Where |
|---|---|
| Text input | `#fullName` |
| Email input | `#email` |
| Telephone input | `#phone` |
| Password input | `#password` |
| Radio buttons | `yearOfStudy` group |
| Checkboxes | `dietary` group, `#consent` |
| Select/dropdown | `#eventSelect` |
| Date input | `#dob` |
| File input | `#idUpload` |
| Textarea | `#notes` |
| Submit/reset buttons | `.form-actions` |
| Client-side validation + messages | `js/script.js` `VALIDATORS`, `displayFormErrors` |

## 3–9. CSS
| Requirement | Where in `css/styles.css` |
|---|---|
| Element/class/ID/attribute/descendant selectors | `body`, `.btn`, `#top`(anchor)/IDs throughout, `input[type="email"]` etc., `.primary-nav a` |
| Pseudo-classes | `:hover`, `:focus-visible`, `:nth-child`, `:not()` |
| Pseudo-elements | `::before`/`::after` on `.hero-date`, `.status-line[data-state="loading"]`, `.notification[data-type="success"]` |
| Reusable classes/variables | `:root` custom properties; `.btn`, `.chip`, `.event-card`, `.form-field` |
| Box model | `box-sizing: border-box` globally; consistent padding/margin/border across cards, form fields, table cells |
| display: block/inline/inline-block/none | `.nav-toggle-bar` (block), `.required-mark` (inline), `.btn`/`.seats-badge` (inline-block), `.primary-nav` on mobile (none) |
| position: relative/absolute/fixed/sticky | `.site-header` (sticky), `.event-card`/`.seats-badge` (relative/absolute), `.notification` (fixed) |
| Flexbox | header, nav, toolbar, button groups, radio/checkbox groups, footer |
| CSS Grid | `.hero-inner`, `.events-grid`, `.form-grid`, `.event-details-body dl` |
| Media queries | `@media (max-width: 992px)` and `@media (max-width: 600px)` — grid columns, nav collapse, font size, form layout |
| Transitions/animations | button/card hover transitions, `@keyframes spin` (loading), `@keyframes slideIn` (notification) |

## 10–21. JavaScript
| Requirement | Where in `js/script.js` |
|---|---|
| Variables & data types (string, number, boolean, array, object, null, undefined) | `selectedEventId` (null until set), `allEvents` (array), event objects, `searchTerm` (string), `seatsAvailable` (number), `isLowSeats`/`consent` (boolean), unset FormData fields (undefined-safe via `|| ""`) |
| Functions & arrow functions | traditional: `loadEvents`, `renderEvents`, `showEventDetails`; arrow: `buildEventCard`, validator functions in `VALIDATORS` |
| Arrays & objects for events/registrations | `allEvents`, `registrations`, individual event/registration objects |
| Array methods: map, filter, find, forEach, some, reduce, sort | `map` (event normalization, select options), `filter` (search/category), `find` (lookup by id), `forEach` (rendering chips/rows), `some` (duplicate-registration check), `reduce` (total seats), `sort` (event ordering) |
| DOM selection/manipulation | `getElementById`, `querySelector`, `querySelectorAll`, `createElement`, `appendChild`, `textContent`, `innerHTML`, `classList` |
| Event handling | click (cards, chips, nav toggle, remove buttons), input (search), change (sort), submit/reset (form) |
| Form validation | `VALIDATORS`, `validateRegistrationForm`, `displayFormErrors` |
| Local Storage | `localStorage.setItem/getItem/removeItem` for registrations and category preference, with `JSON.stringify`/`JSON.parse` |
| Error handling | try/catch around fetch, JSON parsing, and localStorage access; user-facing messages via `showNotification` |
| Promises & async/await | `loadEvents` (async/await over fetch), `checkSeatAvailability` (manual `Promise`), `handleRegistrationSubmit` (awaits both) |
| Fetch API | `loadEvents` fetching `data/events.json`, checks `response.ok`, converts via `response.json()` |
| JSON processing | parsed event array normalized into objects with computed `dateObj` fields |

## Testing
`test_harness.js` (used during development, not required for submission) drove the real
`index.html` + `js/script.js` in a headless DOM and verified: events render from fetched
JSON, search filtering narrows results correctly, invalid form submissions are blocked
with visible errors, a valid submission creates a stored registration, and removing the
last registration clears both the table and the Local Storage key. All checks passed.
