import { getToken, clearSession } from './auth.js';

/**
 * Thin fetch wrapper shared by every page that talks to the Express API.
 * TODO 6: automatically attaches the JWT (when we have one) so protected
 * routes work transparently; a 401 means the session is gone, so we clear
 * it locally too rather than leaving a dead token lying around.
 */
const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';

async function request(path, options = {}) {
  const token = getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  let response;
  try {
    response = await fetch(`${BASE_URL}${path}`, { ...options, headers });
  } catch (networkErr) {
    throw new Error('Could not reach the server. Is the backend running?');
  }

  const isJson = response.headers.get('content-type')?.includes('application/json');
  const body = isJson ? await response.json() : null;

  if (response.status === 401) {
    clearSession(); // the token is missing/invalid/expired - stop pretending we're logged in
  }

  if (!response.ok || body?.success === false) {
    const message = body?.message || `Request failed with status ${response.status}.`;
    const error = new Error(message);
    error.status = response.status;
    error.fieldErrors = body?.errors;
    throw error;
  }

  return body?.data;
}

function withQuery(path, params = {}) {
  const query = new URLSearchParams(
    Object.entries(params).filter(([, value]) => value !== undefined && value !== '')
  ).toString();
  return query ? `${path}?${query}` : path;
}

const get = (path) => request(path, { method: 'GET' });
const post = (path, data) => request(path, { method: 'POST', body: JSON.stringify(data) });
const put = (path, data) => request(path, { method: 'PUT', body: JSON.stringify(data) });
const del = (path) => request(path, { method: 'DELETE' });

// --- Auth / Students (Users) ---
export const registerStudent = (data) => post('/users', data);
export const loginStudent = (data) => post('/users/login', data);
export const fetchMe = () => get('/users/me');
// TODO 12: `search` filters by name/email; the server applies it, but the
// dashboard also filters client-side for instant feedback as the user types.
export const fetchStudents = (search) => get(withQuery('/users', { search }));
export const updateStudent = (id, data) => put(`/users/${id}`, data);
export const deleteStudent = (id) => del(`/users/${id}`);

// --- Tasks ---
// TODO 13: status/assignedUser/date-range filters, applied server-side.
export const fetchTasks = (filters) => get(withQuery('/tasks', filters));
export const createTask = (data) => post('/tasks', data);
export const updateTask = (id, data) => put(`/tasks/${id}`, data);
export const deleteTask = (id) => del(`/tasks/${id}`);

// --- Dashboard ---
export const fetchDashboardSummary = () => get('/dashboard/summary');
