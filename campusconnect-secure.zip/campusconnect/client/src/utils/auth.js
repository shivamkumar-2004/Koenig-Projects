/**
 * Session helper. TODO 5: after login the server issues a JWT; the app
 * remembers it (plus the current user's profile) in localStorage so the
 * Dashboard can attach it to every API call and so a page refresh doesn't
 * log the student out.
 */
const STORAGE_KEY = 'campusconnect.session';

/** @param {{ user: object, token: string }} session */
export function setSession({ user, token }) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({ user, token }));
}

function readSession() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function getCurrentUser() {
  return readSession()?.user || null;
}

export function getToken() {
  return readSession()?.token || null;
}

export function isAuthenticated() {
  return Boolean(getToken());
}

export function clearSession() {
  localStorage.removeItem(STORAGE_KEY);
}
