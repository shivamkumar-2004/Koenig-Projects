import { Navigate, useLocation } from 'react-router-dom';
import { isAuthenticated } from '../../utils/auth.js';

/**
 * TODO 6: Protect Dashboard Access - client-side companion to the
 * server's `protect` middleware. This is a UX guard (skip the flash of a
 * page that will just fail its API calls); the real security boundary is
 * still the server rejecting requests without a valid JWT.
 */
function ProtectedRoute({ children }) {
  const location = useLocation();

  if (!isAuthenticated()) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }

  return children;
}

export default ProtectedRoute;
