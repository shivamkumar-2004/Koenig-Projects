import { useState } from 'react';
import { NavLink, Link, useLocation, useNavigate } from 'react-router-dom';
import { isAuthenticated, clearSession } from '../../utils/auth.js';

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation(); // re-render on navigation so auth state stays current
  const navigate = useNavigate();
  const loggedIn = isAuthenticated();

  const navItems = [
    { to: '/', label: 'Home', end: true },
    { to: '/dashboard', label: 'Dashboard' },
    ...(loggedIn ? [] : [{ to: '/login', label: 'Log in' }, { to: '/register', label: 'Register' }]),
  ];

  function handleLogout() {
    clearSession();
    setMenuOpen(false);
    navigate('/login');
  }

  return (
    <header className="site-header">
      <div className="header-inner">
        <Link to="/" className="brand">
          <span className="brand-mark">CampusConnect</span>
          <span className="brand-sub">student portal</span>
        </Link>

        <button
          type="button"
          className="nav-toggle"
          aria-expanded={menuOpen}
          aria-controls="primary-nav"
          onClick={() => setMenuOpen((open) => !open)}
        >
          {menuOpen ? 'Close' : 'Menu'}
        </button>

        <nav aria-label="Primary" key={location.pathname}>
          <ul id="primary-nav" className={`nav-list ${menuOpen ? 'open' : ''}`}>
            {navItems.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  end={item.end}
                  className={({ isActive }) => (isActive ? 'active' : '')}
                  onClick={() => setMenuOpen(false)}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
            {loggedIn && (
              <li>
                <button type="button" className="nav-logout" onClick={handleLogout}>
                  Log out
                </button>
              </li>
            )}
          </ul>
        </nav>
      </div>
    </header>
  );
}

export default Header;
