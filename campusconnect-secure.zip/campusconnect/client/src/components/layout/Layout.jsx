import Header from './Header.jsx';
import Footer from './Footer.jsx';

/**
 * Shared page shell: Header (with nav) + main content area + Footer.
 * Every route in App.jsx renders its page inside this component so
 * navigation, branding, and spacing stay consistent app-wide.
 */
function Layout({ children }) {
  return (
    <div className="app-shell">
      <Header />
      <main className="main-content">{children}</main>
      <Footer />
    </div>
  );
}

export default Layout;
