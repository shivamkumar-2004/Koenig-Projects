import { useEffect, useState } from 'react';
import Button from '../common/Button.jsx';
import Alert from '../common/Alert.jsx';
import { createTask, updateTask, deleteTask } from '../../utils/api.js';

const STATUS_OPTIONS = ['pending', 'in-progress', 'completed'];
const STATUS_LABEL = { pending: 'Pending', 'in-progress': 'In progress', completed: 'Completed' };

const EMPTY_FORM = { title: '', description: '', assignedUser: '', status: 'pending' };
const EMPTY_FILTERS = { status: '', assignedUser: '', from: '', to: '' };
const DATE_FORMAT = { year: 'numeric', month: 'short', day: 'numeric' };

/**
 * TODO 13: Implement Task Filtering - status, assigned user, creation date.
 * TODO 14: Display task details/status, refreshed after changes.
 * TODO 15: Create new tasks from React and verify they land in MongoDB.
 * TODO 16: Update task details / change status from React.
 * TODO 17: Remove tasks and verify they're deleted from MongoDB.
 */
function TaskBoard({ tasks, students, loading, error, onChanged, onFilterChange }) {
  const [form, setForm] = useState(EMPTY_FORM);
  const [creating, setCreating] = useState(false);
  const [formError, setFormError] = useState('');

  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState(EMPTY_FORM);
  const [busyId, setBusyId] = useState(null);
  const [actionError, setActionError] = useState('');

  const [filters, setFilters] = useState(EMPTY_FILTERS);

  // Debounce the date inputs; dropdowns feel better firing immediately,
  // but a single effect keeps the logic in one place.
  useEffect(() => {
    const timer = window.setTimeout(() => onFilterChange(filters), 250);
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters]);

  function handleFilterChange(e) {
    const { name, value } = e.target;
    setFilters((f) => ({ ...f, [name]: value }));
  }

  async function handleCreate(event) {
    event.preventDefault();
    setFormError('');

    if (!form.title.trim()) {
      setFormError('Task title is required.');
      return;
    }

    setCreating(true);
    try {
      await createTask({
        title: form.title.trim(),
        description: form.description.trim(),
        status: form.status,
        assignedUser: form.assignedUser || null,
      });
      setForm(EMPTY_FORM);
      onChanged();
    } catch (err) {
      setFormError(err.message || 'Could not create this task.');
    } finally {
      setCreating(false);
    }
  }

  function startEdit(task) {
    setActionError('');
    setEditingId(task._id);
    setEditForm({
      title: task.title,
      description: task.description || '',
      assignedUser: task.assignedUser?._id || '',
      status: task.status,
    });
  }

  function cancelEdit() {
    setEditingId(null);
  }

  async function saveEdit(id) {
    setActionError('');
    setBusyId(id);
    try {
      await updateTask(id, {
        title: editForm.title.trim(),
        description: editForm.description.trim(),
        status: editForm.status,
        assignedUser: editForm.assignedUser || null,
      });
      setEditingId(null);
      onChanged();
    } catch (err) {
      setActionError(err.message || 'Could not update this task.');
    } finally {
      setBusyId(null);
    }
  }

  async function handleDelete(id) {
    if (!window.confirm('Delete this task? This cannot be undone.')) return;
    setActionError('');
    setBusyId(id);
    try {
      await deleteTask(id);
      onChanged();
    } catch (err) {
      setActionError(err.message || 'Could not delete this task.');
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <form className="inline-form" onSubmit={handleCreate} noValidate>
        <Alert type="error" message={formError} />
        <div className="inline-form-row">
          <input
            className="table-input"
            name="title"
            placeholder="Task title"
            value={form.title}
            onChange={handleFormChange}
          />
          <input
            className="table-input"
            name="description"
            placeholder="Description (optional)"
            value={form.description}
            onChange={handleFormChange}
          />
          <select
            className="table-input"
            name="assignedUser"
            value={form.assignedUser}
            onChange={handleFormChange}
          >
            <option value="">Unassigned</option>
            {students.map((s) => (
              <option key={s._id} value={s._id}>
                {s.name}
              </option>
            ))}
          </select>
          <Button type="submit" disabled={creating}>
            {creating ? 'Adding…' : 'Add task'}
          </Button>
        </div>
      </form>

      <div className="filter-row">
        <select
          className="table-input"
          name="status"
          value={filters.status}
          onChange={handleFilterChange}
          aria-label="Filter by status"
        >
          <option value="">All statuses</option>
          {STATUS_OPTIONS.map((opt) => (
            <option key={opt} value={opt}>
              {STATUS_LABEL[opt]}
            </option>
          ))}
        </select>
        <select
          className="table-input"
          name="assignedUser"
          value={filters.assignedUser}
          onChange={handleFilterChange}
          aria-label="Filter by assigned student"
        >
          <option value="">Everyone</option>
          <option value="unassigned">Unassigned</option>
          {students.map((s) => (
            <option key={s._id} value={s._id}>
              {s.name}
            </option>
          ))}
        </select>
        <label className="filter-date-label">
          From
          <input
            className="table-input"
            type="date"
            name="from"
            value={filters.from}
            onChange={handleFilterChange}
          />
        </label>
        <label className="filter-date-label">
          To
          <input
            className="table-input"
            type="date"
            name="to"
            value={filters.to}
            onChange={handleFilterChange}
          />
        </label>
        {(filters.status || filters.assignedUser || filters.from || filters.to) && (
          <Button variant="secondary" onClick={() => setFilters(EMPTY_FILTERS)}>
            Clear filters
          </Button>
        )}
      </div>

      {loading ? (
        <div className="loading-line">
          <span className="spinner" aria-hidden="true" />
          Loading tasks…
        </div>
      ) : error ? (
        <Alert type="error" message={error} />
      ) : tasks.length === 0 ? (
        <p>No tasks match the current filters.</p>
      ) : (
        <div>
          <Alert type="error" message={actionError} />
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Assigned to</th>
                  <th>Status</th>
                  <th>Created</th>
                  <th aria-label="Actions" />
                </tr>
              </thead>
              <tbody>
                {tasks.map((task) => (
                  <tr key={task._id}>
                    {editingId === task._id ? (
                      <>
                        <td>
                          <input
                            className="table-input"
                            value={editForm.title}
                            onChange={(e) =>
                              setEditForm((f) => ({ ...f, title: e.target.value }))
                            }
                          />
                          <input
                            className="table-input"
                            placeholder="Description"
                            value={editForm.description}
                            onChange={(e) =>
                              setEditForm((f) => ({ ...f, description: e.target.value }))
                            }
                          />
                        </td>
                        <td>
                          <select
                            className="table-input"
                            value={editForm.assignedUser}
                            onChange={(e) =>
                              setEditForm((f) => ({ ...f, assignedUser: e.target.value }))
                            }
                          >
                            <option value="">Unassigned</option>
                            {students.map((s) => (
                              <option key={s._id} value={s._id}>
                                {s.name}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td>
                          <select
                            className="table-input"
                            value={editForm.status}
                            onChange={(e) =>
                              setEditForm((f) => ({ ...f, status: e.target.value }))
                            }
                          >
                            {STATUS_OPTIONS.map((opt) => (
                              <option key={opt} value={opt}>
                                {STATUS_LABEL[opt]}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="task-created-cell">
                          {new Date(task.createdAt).toLocaleDateString(undefined, DATE_FORMAT)}
                        </td>
                        <td className="table-actions">
                          <Button
                            variant="primary"
                            onClick={() => saveEdit(task._id)}
                            disabled={busyId === task._id}
                          >
                            Save
                          </Button>
                          <Button variant="secondary" onClick={cancelEdit}>
                            Cancel
                          </Button>
                        </td>
                      </>
                    ) : (
                      <>
                        <td>
                          <strong>{task.title}</strong>
                          {task.description ? <div className="task-desc">{task.description}</div> : null}
                        </td>
                        <td>{task.assignedUser?.name || 'Unassigned'}</td>
                        <td>
                          <span className={`status-badge status-${task.status}`}>
                            {STATUS_LABEL[task.status]}
                          </span>
                        </td>
                        <td>{new Date(task.createdAt).toLocaleDateString(undefined, DATE_FORMAT)}</td>
                        <td className="table-actions">
                          <Button variant="secondary" onClick={() => startEdit(task)}>
                            Edit
                          </Button>
                          <Button
                            variant="secondary"
                            onClick={() => handleDelete(task._id)}
                            disabled={busyId === task._id}
                          >
                            Delete
                          </Button>
                        </td>
                      </>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

export default TaskBoard;
