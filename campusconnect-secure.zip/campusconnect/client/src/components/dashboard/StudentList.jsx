import { useEffect, useState } from 'react';
import Button from '../common/Button.jsx';
import Alert from '../common/Alert.jsx';
import { updateStudent, deleteStudent } from '../../utils/api.js';

const DATE_FORMAT = { year: 'numeric', month: 'short', day: 'numeric' };

/**
 * TODO 12: Search students by name/email, dynamically.
 * TODO 13: Display registered students / profile information from MongoDB.
 * TODO 16: Allow profile information to be modified from React.
 * TODO 17: Allow student records to be removed, verified against MongoDB.
 */
function StudentList({ students, loading, error, onChanged, onSearch }) {
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({ name: '', email: '' });
  const [actionError, setActionError] = useState('');
  const [busyId, setBusyId] = useState(null);
  const [searchInput, setSearchInput] = useState('');

  // Debounce so we're not firing a request on every keystroke.
  useEffect(() => {
    const timer = window.setTimeout(() => onSearch(searchInput.trim()), 300);
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchInput]);

  function startEdit(student) {
    setActionError('');
    setEditingId(student._id);
    setEditForm({ name: student.name, email: student.email });
  }

  function cancelEdit() {
    setEditingId(null);
  }

  async function saveEdit(id) {
    setActionError('');
    setBusyId(id);
    try {
      await updateStudent(id, editForm);
      setEditingId(null);
      onChanged();
    } catch (err) {
      setActionError(err.message || 'Could not update this student.');
    } finally {
      setBusyId(null);
    }
  }

  async function handleDelete(id) {
    if (!window.confirm('Remove this student record? This cannot be undone.')) return;
    setActionError('');
    setBusyId(id);
    try {
      await deleteStudent(id);
      onChanged();
    } catch (err) {
      setActionError(err.message || 'Could not delete this student.');
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <div className="search-row">
        <input
          className="table-input search-input"
          type="search"
          placeholder="Search by name or email…"
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
          aria-label="Search students"
        />
      </div>

      {loading ? (
        <div className="loading-line">
          <span className="spinner" aria-hidden="true" />
          Loading students…
        </div>
      ) : error ? (
        <Alert type="error" message={error} />
      ) : students.length === 0 ? (
        <p>{searchInput ? 'No students match your search.' : 'No students have registered yet.'}</p>
      ) : (
        <div>
          <Alert type="error" message={actionError} />
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Registered</th>
                  <th aria-label="Actions" />
                </tr>
              </thead>
              <tbody>
                {students.map((student) => (
                  <tr key={student._id}>
                    {editingId === student._id ? (
                      <>
                        <td>
                          <input
                            className="table-input"
                            value={editForm.name}
                            onChange={(e) => setEditForm((f) => ({ ...f, name: e.target.value }))}
                          />
                        </td>
                        <td>
                          <input
                            className="table-input"
                            type="email"
                            value={editForm.email}
                            onChange={(e) => setEditForm((f) => ({ ...f, email: e.target.value }))}
                          />
                        </td>
                        <td>
                          {new Date(student.createdAt).toLocaleDateString(undefined, DATE_FORMAT)}
                        </td>
                        <td className="table-actions">
                          <Button
                            variant="primary"
                            onClick={() => saveEdit(student._id)}
                            disabled={busyId === student._id}
                          >
                            Save
                          </Button>
                          <Button variant="secondary" onClick={cancelEdit}>
                            Cancel
                          </Button>
                        </td>
                      </>
                    ) : (
                      <>
                        <td>{student.name}</td>
                        <td>{student.email}</td>
                        <td>
                          {new Date(student.createdAt).toLocaleDateString(undefined, DATE_FORMAT)}
                        </td>
                        <td className="table-actions">
                          <Button variant="secondary" onClick={() => startEdit(student)}>
                            Edit
                          </Button>
                          <Button
                            variant="secondary"
                            onClick={() => handleDelete(student._id)}
                            disabled={busyId === student._id}
                          >
                            Delete
                          </Button>
                        </td>
                      </>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

export default StudentList;
