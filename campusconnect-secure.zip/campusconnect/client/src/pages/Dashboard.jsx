import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import announcementsData from '../data/announcements.js';
import StudentList from '../components/dashboard/StudentList.jsx';
import TaskBoard from '../components/dashboard/TaskBoard.jsx';
import { fetchStudents, fetchTasks, fetchDashboardSummary } from '../utils/api.js';
import { getCurrentUser, clearSession } from '../utils/auth.js';

function Dashboard() {
  const navigate = useNavigate();
  const currentUser = getCurrentUser();

  // Announcements stay as front-end mock data (no backend model in this lab).
  const [announcements, setAnnouncements] = useState([]);
  const [announcementsLoading, setAnnouncementsLoading] = useState(true);

  // TODO 12: Retrieve database records - students and tasks come from the API.
  const [students, setStudents] = useState([]);
  const [studentsLoading, setStudentsLoading] = useState(true);
  const [studentsError, setStudentsError] = useState('');
  const [studentSearch, setStudentSearch] = useState('');

  const [tasks, setTasks] = useState([]);
  const [tasksLoading, setTasksLoading] = useState(true);
  const [tasksError, setTasksError] = useState('');
  const [taskFilters, setTaskFilters] = useState({});

  // TODO 14: dashboard-wide summary, computed server-side with the array
  // utilities in server/src/utils/dataUtils.js.
  const [summary, setSummary] = useState(null);

  /** A 401 means the token is gone (missing/expired/invalid) - bounce to login. */
  function handleAuthFailure(err) {
    if (err.status === 401) {
      clearSession();
      navigate('/login');
      return true;
    }
    return false;
  }

  const loadStudents = useCallback(
    async (search = studentSearch) => {
      setStudentsLoading(true);
      setStudentsError('');
      try {
        const data = await fetchStudents(search);
        setStudents(data);
      } catch (err) {
        if (!handleAuthFailure(err)) setStudentsError(err.message || 'Could not load students.');
      } finally {
        setStudentsLoading(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [studentSearch]
  );

  const loadTasks = useCallback(
    async (filters = taskFilters) => {
      setTasksLoading(true);
      setTasksError('');
      try {
        const data = await fetchTasks(filters);
        setTasks(data);
      } catch (err) {
        if (!handleAuthFailure(err)) setTasksError(err.message || 'Could not load tasks.');
      } finally {
        setTasksLoading(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [taskFilters]
  );

  const loadSummary = useCallback(async () => {
    try {
      const data = await fetchDashboardSummary();
      setSummary(data);
    } catch (err) {
      handleAuthFailure(err);
      // A failed summary shouldn't block the rest of the dashboard; the
      // stat row below just falls back to values derived from `tasks`/`students`.
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Initial load.
  useEffect(() => {
    const timer = window.setTimeout(() => {
      setAnnouncements(announcementsData);
      setAnnouncementsLoading(false);
    }, 500);

    loadStudents('');
    loadTasks({});
    loadSummary();

    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function handleStudentSearch(term) {
    setStudentSearch(term);
    loadStudents(term);
  }

  function handleTaskFilterChange(filters) {
    setTaskFilters(filters);
    loadTasks(filters);
  }

  function refreshEverything() {
    loadStudents();
    loadTasks();
    loadSummary();
  }

  const stats = summary
    ? [
        { label: 'Announcements', value: announcements.length },
        { label: 'Registered students', value: summary.totalStudents },
        { label: 'Open tasks', value: summary.incompleteTasks },
      ]
    : [
        { label: 'Announcements', value: announcements.length },
        { label: 'Registered students', value: students.length },
        { label: 'Open tasks', value: tasks.filter((t) => t.status !== 'completed').length },
      ];

  return (
    <div>
      <div className="dash-header">
        <div className="dash-greeting">
          <h1 style={{ marginBottom: '0.2rem' }}>
            {currentUser ? `Welcome back, ${currentUser.name}` : 'Welcome back'}
          </h1>
          <p>Here's what's happening across campus this week.</p>
        </div>
      </div>

      <div className="stat-row">
        {stats.map((stat) => (
          <div className="stat" key={stat.label}>
            <span className="stat-num">{stat.value}</span>
            <span className="stat-label">{stat.label}</span>
          </div>
        ))}
      </div>

      {summary && (
        <div className="status-breakdown">
          <span className="status-badge status-pending">Pending: {summary.tasksByStatus.pending}</span>
          <span className="status-badge status-in-progress">
            In progress: {summary.tasksByStatus['in-progress']}
          </span>
          <span className="status-badge status-completed">
            Completed: {summary.tasksByStatus.completed}
          </span>
        </div>
      )}

      <div className="section-title-row">
        <h2>Announcements</h2>
      </div>

      {announcementsLoading ? (
        <div className="loading-line">
          <span className="spinner" aria-hidden="true" />
          Loading announcements…
        </div>
      ) : announcements.length === 0 ? (
        <p>There are no announcements right now. Check back soon.</p>
      ) : (
        <div className="notice-board">
          {announcements.map((item) => (
            <article className="notice" key={item.id}>
              <div className="notice-meta">
                <span className="notice-tag">{item.tag}</span>
                <span>{item.date}</span>
              </div>
              <h3>{item.title}</h3>
              <p>{item.body}</p>
            </article>
          ))}
        </div>
      )}

      <div className="section-title-row dash-section">
        <h2>Registered students</h2>
      </div>
      <p>Live from MongoDB via GET /api/users. Search updates the list as you type.</p>
      <StudentList
        students={students}
        loading={studentsLoading}
        error={studentsError}
        onChanged={refreshEverything}
        onSearch={handleStudentSearch}
      />

      <div className="section-title-row dash-section">
        <h2>Tasks</h2>
      </div>
      <p>Live from MongoDB via GET /api/tasks. Filter by status, student, or creation date.</p>
      <TaskBoard
        tasks={tasks}
        students={students}
        loading={tasksLoading}
        error={tasksError}
        onChanged={refreshEverything}
        onFilterChange={handleTaskFilterChange}
      />
    </div>
  );
}

export default Dashboard;
