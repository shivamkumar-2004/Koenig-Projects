/**
 * TODO 11: Review JavaScript Data Operations.
 * TODO 14: Solve Data Processing Challenges.
 * -----------------------------------------------------------------------
 * Small, pure, well-named functions over plain arrays/objects - each one
 * picks the array method that actually fits the job (find for "the one
 * matching item", filter for "a subset", reduce for "fold into one
 * value/shape") instead of a generic for-loop doing everything. They're
 * unit-testable in isolation and reused by dashboardController.js.
 */

/** @typedef {import('../types.js').User} User */
/** @typedef {import('../types.js').Task} Task */

/**
 * Find a single student by exact email (case-insensitive) or Mongo id.
 * Uses `find` because we want the one matching record, not a subset.
 * @param {User[]} students
 * @param {string} query
 * @returns {User|undefined}
 */
export function findStudent(students, query) {
  const needle = query.trim().toLowerCase();
  return students.find(
    (student) => student.email.toLowerCase() === needle || student._id === query
  );
}

/**
 * Case-insensitive partial match search across name and email.
 * Uses `filter` because zero, one, or many results are all valid.
 * @param {User[]} students
 * @param {string} term
 * @returns {User[]}
 */
export function searchStudents(students, term) {
  if (!term) return students;
  const needle = term.trim().toLowerCase();
  return students.filter(
    (student) =>
      student.name.toLowerCase().includes(needle) || student.email.toLowerCase().includes(needle)
  );
}

/**
 * Tasks that are not yet completed.
 * @param {Task[]} tasks
 * @returns {Task[]}
 */
export function getIncompleteTasks(tasks) {
  return tasks.filter((task) => task.status !== 'completed');
}

/**
 * Count of completed tasks. `reduce` folds the array down to one number.
 * @param {Task[]} tasks
 * @returns {number}
 */
export function countCompletedTasks(tasks) {
  return tasks.reduce((count, task) => (task.status === 'completed' ? count + 1 : count), 0);
}

/**
 * Group tasks by status into a lookup object, e.g.
 * { pending: [...], 'in-progress': [...], completed: [...] }.
 * `reduce` is the right tool because we're folding a list into a shape,
 * not filtering it down to a subset.
 * @param {Task[]} tasks
 * @returns {Object.<string, Task[]>}
 */
export function groupTasksByStatus(tasks) {
  return tasks.reduce((groups, task) => {
    const key = task.status;
    if (!groups[key]) groups[key] = [];
    groups[key].push(task);
    return groups;
  }, {});
}

/**
 * Group tasks by the id of the student they're assigned to.
 * Unassigned tasks are bucketed under the 'unassigned' key.
 * @param {Task[]} tasks
 * @returns {Object.<string, Task[]>}
 */
export function groupTasksByOwner(tasks) {
  return tasks.reduce((groups, task) => {
    const owner = task.assignedUser;
    const ownerId = (typeof owner === 'object' && owner?._id) || owner || 'unassigned';
    if (!groups[ownerId]) groups[ownerId] = [];
    groups[ownerId].push(task);
    return groups;
  }, {});
}

/**
 * Pulls everything above into one dashboard-ready summary object.
 * Demonstrates map/filter/reduce/find composed together rather than one
 * big imperative loop.
 * @param {User[]} students
 * @param {Task[]} tasks
 */
export function buildDashboardSummary(students, tasks) {
  const byStatus = groupTasksByStatus(tasks);

  return {
    totalStudents: students.length,
    totalTasks: tasks.length,
    completedTasks: countCompletedTasks(tasks),
    incompleteTasks: getIncompleteTasks(tasks).length,
    tasksByStatus: {
      pending: byStatus.pending?.length || 0,
      'in-progress': byStatus['in-progress']?.length || 0,
      completed: byStatus.completed?.length || 0,
    },
    // map: turn each student into a lightweight { id, name, taskCount } row.
    workloadByStudent: students.map((student) => {
      const owned = tasks.filter((task) => {
        const owner = task.assignedUser;
        const ownerId = (typeof owner === 'object' && owner?._id) || owner;
        return ownerId === student._id;
      });
      return {
        id: student._id,
        name: student.name,
        taskCount: owned.length,
        openTaskCount: getIncompleteTasks(owned).length,
      };
    }),
  };
}
