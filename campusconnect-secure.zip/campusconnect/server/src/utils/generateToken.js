import jwt from 'jsonwebtoken';

/** @typedef {import('../types.js').AuthPayload} AuthPayload */

/**
 * TODO 5: Implement Token-Based Authentication.
 * Signs a short-lived JWT carrying just enough to authorize future
 * requests (user id + role) - never the password hash or full profile.
 *
 * @param {{ _id: *, role: string }} user
 * @returns {string}
 */
export function generateToken(user) {
  if (!process.env.JWT_SECRET) {
    throw new Error('JWT_SECRET is not configured on the server.');
  }
  return jwt.sign({ id: user._id.toString(), role: user.role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '1d',
  });
}

/**
 * @param {string} token
 * @returns {AuthPayload}
 */
export function verifyToken(token) {
  return jwt.verify(token, process.env.JWT_SECRET);
}
