/**
 * TODO 9: Refactor Data Structures.
 * -----------------------------------------------------------------------
 * This project stays plain JavaScript at runtime (Node/MongoDB, no build
 * step), but we apply TypeScript *concepts* - shared, named shapes checked
 * statically - via JSDoc typedefs. Run `npm run typecheck` (tsc --noEmit
 * with checkJs) to have these enforced across the codebase without adding
 * a compile step. Every model/controller below references these typedefs
 * with `@param {import('../types.js').Task} task` so every developer on
 * the team works from the same field names instead of inventing their own.
 */

/**
 * @typedef {'student' | 'faculty' | 'admin'} Role
 */

/**
 * The single, standardized shape for a user everywhere in the app:
 * identity fields, authentication fields, and role - grouped explicitly
 * so nothing gets bolted on inconsistently later.
 *
 * @typedef {Object} User
 * @property {*} _id                       - Mongo ObjectId (raw doc) or string (serialized)
 * @property {string} name               - Identity
 * @property {string} email               - Identity / login credential
 * @property {string} [password]          - Authentication (hashed, select:false, never sent to clients)
 * @property {Role} role                  - Authorization
 * @property {string} createdAt           - Profile / audit
 * @property {string} updatedAt           - Profile / audit
 */

/**
 * @typedef {'pending' | 'in-progress' | 'completed'} TaskStatus
 */

/**
 * @typedef {Object} Task
 * @property {*} _id                       - Mongo ObjectId (raw doc) or string (serialized)
 * @property {string} title               - Task information
 * @property {string} description         - Task information
 * @property {TaskStatus} status           - Status
 * @property {(string|User|null)} assignedUser - Ownership (ref to User, populated or raw id)
 * @property {string} createdAt           - Timestamps
 * @property {string} updatedAt           - Timestamps
 */

/**
 * The one response envelope every API route returns, success or failure.
 * @typedef {Object} ApiResponse
 * @property {boolean} success
 * @property {*} [data]
 * @property {string} [message]
 * @property {Object.<string,string>} [errors]
 */

/**
 * Decoded JWT payload attached to `req.user` by the `protect` middleware.
 * @typedef {Object} AuthPayload
 * @property {string} id
 * @property {Role} role
 */

export {};
