import Task from '../models/Task.js';

/** @typedef {import('../types.js').Task} Task */

const ASSIGNED_USER_FIELDS = 'name email';

/**
 * TODO 9/13: Implement CRUD Operations - Task Management, with support
 * for filtering by status, assigned user, and creation date.
 */

// POST /api/tasks  (protected)
export async function createTask(req, res) {
  const { title, description, status, assignedUser } = req.body;

  const task = await Task.create({
    title,
    description,
    status,
    assignedUser: assignedUser || null,
  });
  await task.populate('assignedUser', ASSIGNED_USER_FIELDS);

  res.status(201).json({
    success: true,
    message: 'Task created successfully.',
    data: task,
  });
}

// GET /api/tasks?status=&assignedUser=&from=&to=  (protected)
// TODO 13: Implement Task Filtering - status, ownership, and a creation-date range.
export async function getTasks(req, res) {
  const { status, assignedUser, from, to } = req.query;

  // Build the Mongo filter object incrementally so only the params the
  // client actually sent are applied - unset filters must not exclude data.
  const filter = {};
  if (status) filter.status = status;
  if (assignedUser) filter.assignedUser = assignedUser === 'unassigned' ? null : assignedUser;
  if (from || to) {
    filter.createdAt = {};
    if (from) filter.createdAt.$gte = new Date(from);
    if (to) filter.createdAt.$lte = new Date(to);
  }

  const tasks = await Task.find(filter)
    .sort({ createdAt: -1 })
    .populate('assignedUser', ASSIGNED_USER_FIELDS);

  res.json({ success: true, data: tasks });
}

// GET /api/tasks/:id  (protected)
export async function getTaskById(req, res) {
  const task = await Task.findById(req.params.id).populate('assignedUser', ASSIGNED_USER_FIELDS);
  if (!task) {
    return res.status(404).json({ success: false, message: 'Task not found.' });
  }
  res.json({ success: true, data: task });
}

// PUT /api/tasks/:id  (protected)
export async function updateTask(req, res) {
  const { title, description, status, assignedUser } = req.body;
  const task = await Task.findById(req.params.id);

  if (!task) {
    return res.status(404).json({ success: false, message: 'Task not found.' });
  }

  if (title !== undefined) task.title = title;
  if (description !== undefined) task.description = description;
  if (status !== undefined) task.status = status;
  if (assignedUser !== undefined) task.assignedUser = assignedUser || null;

  await task.save();
  await task.populate('assignedUser', ASSIGNED_USER_FIELDS);

  res.json({
    success: true,
    message: 'Task updated successfully.',
    data: task,
  });
}

// DELETE /api/tasks/:id  (protected)
export async function deleteTask(req, res) {
  const task = await Task.findByIdAndDelete(req.params.id);
  if (!task) {
    return res.status(404).json({ success: false, message: 'Task not found.' });
  }
  res.json({ success: true, message: 'Task deleted successfully.', data: { id: req.params.id } });
}
