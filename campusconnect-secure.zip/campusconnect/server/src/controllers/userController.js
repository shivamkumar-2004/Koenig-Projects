import User from '../models/User.js';
import { generateToken } from '../utils/generateToken.js';
import { searchStudents } from '../utils/dataUtils.js';

/** @typedef {import('../types.js').User} User */

/**
 * TODO 2/3/9: Implement CRUD Operations - User Management, with
 * standardized fields, hashed passwords, and token issuance on login.
 */

// POST /api/users  (public - Register form)
export async function createUser(req, res) {
  const { name, email, password } = req.body;

  // TODO 2: Prevent duplicate accounts with a clear message up front
  // (the schema's unique index is the real guarantee; this just avoids
  // making the client wait on a generic 11000 error for the common case).
  const existing = await User.findOne({ email: email?.toLowerCase().trim() });
  if (existing) {
    return res.status(409).json({
      success: false,
      message: 'An account with that email already exists.',
      errors: { email: 'This email is already registered.' },
    });
  }

  const user = await User.create({ name, email, password }); // role defaults to 'student'
  const token = generateToken(user);

  res.status(201).json({
    success: true,
    message: 'Student registered successfully.',
    data: { user, token },
  });
}

// POST /api/users/login  (public)
export async function loginUser(req, res) {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({
      success: false,
      message: 'Email and password are required.',
    });
  }

  // TODO 3/4: verify credentials against the hash - never compare plain text.
  const user = await User.findOne({ email: email.toLowerCase().trim() }).select('+password');

  if (!user || !(await /** @type {any} */ (user).comparePassword(password))) {
    return res.status(401).json({
      success: false,
      message: 'Invalid email or password.',
    });
  }

  // TODO 5: issue a token the client will send on every future request.
  const token = generateToken(user);

  res.json({
    success: true,
    message: `Welcome back, ${user.name}.`,
    data: { user, token }, // toJSON transform strips the password hash
  });
}

// GET /api/users/me  (protected - "who am I" check for the client on load/refresh)
export async function getMe(req, res) {
  res.json({ success: true, data: req.user });
}

// GET /api/users?search=term  (protected)
export async function getUsers(req, res) {
  const users = await User.find().sort({ createdAt: -1 });

  // TODO 12: Implement Student Search Functionality (server-side, using
  // the shared array-based utility so client and server share one
  // definition of "matches the search term").
  const { search } = req.query;
  // See the note in dashboardController.js: Mongoose infers `role` as a
  // plain string from the schema, while our typedef narrows it to a
  // literal union for the rest of the app.
  // @ts-ignore
  const results = search ? searchStudents(users, String(search)) : users;

  res.json({ success: true, data: results });
}

// GET /api/users/:id  (protected)
export async function getUserById(req, res) {
  const user = await User.findById(req.params.id);
  if (!user) {
    return res.status(404).json({ success: false, message: 'Student not found.' });
  }
  res.json({ success: true, data: user });
}

// PUT /api/users/:id  (protected)
export async function updateUser(req, res) {
  const { name, email, password } = req.body;
  const user = await User.findById(req.params.id);

  if (!user) {
    return res.status(404).json({ success: false, message: 'Student not found.' });
  }

  if (name !== undefined) user.name = name;
  if (email !== undefined) user.email = email;
  if (password) user.password = password; // triggers the pre-save hash hook

  await user.save();

  res.json({
    success: true,
    message: 'Student record updated.',
    data: user,
  });
}

// DELETE /api/users/:id  (protected - any authenticated user for now; see docs/ROLES.md
// for the role-restriction this can be upgraded to with `authorize('admin')`)
export async function deleteUser(req, res) {
  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) {
    return res.status(404).json({ success: false, message: 'Student not found.' });
  }
  res.json({ success: true, message: 'Student record deleted.', data: { id: req.params.id } });
}
