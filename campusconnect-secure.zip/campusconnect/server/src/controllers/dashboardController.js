import User from '../models/User.js';
import Task from '../models/Task.js';
import { buildDashboardSummary } from '../utils/dataUtils.js';

/**
 * TODO 14: Solve Data Processing Challenges.
 * Fetches the current students/tasks and folds them into one summary
 * object using the array-method utilities in utils/dataUtils.js, rather
 * than re-deriving counts ad hoc wherever they're needed.
 */

// GET /api/dashboard/summary  (protected)
export async function getDashboardSummary(req, res) {
  const [students, tasks] = await Promise.all([
    User.find().sort({ createdAt: -1 }),
    Task.find().populate('assignedUser', 'name email'),
  ]);

  // Mongoose infers `role`/`status` as plain `string` from the schema
  // definition, while our JSDoc typedefs narrow them to specific string
  // literals for everywhere else in the app that consumes already-shaped
  // data. This is the one seam between the two type systems.
  // @ts-ignore
  const summary = buildDashboardSummary(students, tasks);

  res.json({ success: true, data: summary });
}
