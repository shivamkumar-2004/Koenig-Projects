import { verifyToken } from '../utils/generateToken.js';
import User from '../models/User.js';

/** @typedef {import('../types.js').AuthPayload} AuthPayload */

/**
 * TODO 6: Protect Dashboard Access.
 * Reads `Authorization: Bearer <token>`, verifies it, and loads the user
 * onto `req.user` (password excluded by the schema's `select: false`).
 * Any missing/invalid/expired token is rejected with 401 before the
 * request ever reaches a controller or touches the database.
 */
export async function protect(req, res, next) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({
      success: false,
      message: 'Not authorized. Please log in and try again.',
    });
  }

  try {
    /** @type {AuthPayload} */
    const payload = verifyToken(token);
    const user = await User.findById(payload.id);

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Not authorized. The account for this token no longer exists.',
      });
    }

    req.user = user; // available to every downstream handler
    next();
  } catch (err) {
    const message =
      err.name === 'TokenExpiredError'
        ? 'Your session has expired. Please log in again.'
        : 'Not authorized. Invalid authentication token.';
    return res.status(401).json({ success: false, message });
  }
}

/**
 * TODO 7: Prepare Role-Based Access Design.
 * Usage: router.delete('/:id', protect, authorize('admin'), deleteUser)
 * `protect` must run first so `req.user` is populated. See
 * docs/ROLES.md for what each role is intended to access.
 *
 * @param {...import('../types.js').Role} allowedRoles
 */
export function authorize(...allowedRoles) {
  return function checkRole(req, res, next) {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Not authorized.' });
    }
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Access denied. This action requires one of: ${allowedRoles.join(', ')}.`,
      });
    }
    next();
  };
}
