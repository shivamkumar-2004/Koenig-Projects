/**
 * TODO 4 / TODO 10: structured, consistent success & error responses.
 * Every response from this API follows the shape:
 *   { success: boolean, data?: any, message?: string, errors?: object }
 */

// Mounted after all routes: catches requests to endpoints that don't exist.
export function notFound(req, res, next) {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.method} ${req.originalUrl}`,
  });
}

// Mounted last: catches every error passed via next(err) from any route.
// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  console.error('[error]', err.message);

  // Mongoose validation error -> 400 with a field-by-field message map.
  if (err.name === 'ValidationError') {
    const errors = {};
    for (const field of Object.keys(err.errors)) {
      errors[field] = err.errors[field].message;
    }
    return res.status(400).json({
      success: false,
      message: 'Validation failed. Please check the highlighted fields.',
      errors,
    });
  }

  // Mongoose duplicate key error (e.g. an email that's already registered).
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue || {})[0] || 'field';
    return res.status(409).json({
      success: false,
      message: `That ${field} is already in use.`,
      errors: { [field]: `This ${field} is already registered.` },
    });
  }

  // Mongoose "cast" error -> usually an invalid ObjectId in a URL param.
  if (err.name === 'CastError') {
    return res.status(400).json({
      success: false,
      message: `Invalid ${err.path}: ${err.value}`,
    });
  }

  // JWT errors that reach here (defense in depth; `protect` normally catches these itself).
  if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
    return res.status(401).json({
      success: false,
      message:
        err.name === 'TokenExpiredError'
          ? 'Your session has expired. Please log in again.'
          : 'Invalid authentication token.',
    });
  }

  // The database isn't connected yet (see config/db.js).
  if (err.name === 'MongoNotConnectedError' || err.message?.includes('buffering timed out')) {
    return res.status(503).json({
      success: false,
      message: 'Database is not connected. Check MONGODB_URI and try again.',
    });
  }

  // Anything else the route explicitly threw with a status code.
  const statusCode = err.statusCode && err.statusCode >= 400 ? err.statusCode : 500;
  res.status(statusCode).json({
    success: false,
    message: statusCode === 500 ? 'Something went wrong on the server.' : err.message,
  });
}
