import 'dotenv/config';
import express from 'express';
import cors from 'cors';

import connectDB from './config/db.js';
import requestLogger from './middleware/logger.js';
import { notFound, errorHandler } from './middleware/errorHandler.js';
import userRoutes from './routes/userRoutes.js';
import taskRoutes from './routes/taskRoutes.js';
import dashboardRoutes from './routes/dashboardRoutes.js';

const app = express();
const PORT = process.env.PORT || 5000;

if (!process.env.JWT_SECRET) {
  console.warn(
    '[auth] JWT_SECRET is not set. Copy server/.env.example to server/.env and set a ' +
      'real secret, or login/protected routes will fail with a 500 error.'
  );
}

// TODO 2: Configure Middleware
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json()); // parses incoming JSON payloads onto req.body
app.use(requestLogger); // logs method, path, status code, and timing

// TODO 3/4/6: REST API routes - Student (User), Task, and Dashboard resources
app.use('/api/users', userRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/dashboard', dashboardRoutes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'campusconnect-server' });
});

// Anything below the routes above is either a bad route or an error.
app.use(notFound);
app.use(errorHandler);

async function start() {
  app.listen(PORT, () => {
    console.log(`CampusConnect API listening on http://localhost:${PORT}`);
  });
  await connectDB(); // TODO 6: Configure MongoDB Connection (runs alongside, not blocking, the HTTP listener)
}

start();
