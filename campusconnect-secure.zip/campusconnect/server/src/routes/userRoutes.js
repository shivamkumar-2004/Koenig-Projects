import { Router } from 'express';
import asyncHandler from '../utils/asyncHandler.js';
import { protect } from '../middleware/auth.js';
import {
  createUser,
  loginUser,
  getMe,
  getUsers,
  getUserById,
  updateUser,
  deleteUser,
} from '../controllers/userController.js';

/**
 * TODO 3: Design REST API Structure - Student/User resource.
 * TODO 6: Protect Dashboard Access - every route below except register
 * and login now requires a valid `Authorization: Bearer <token>` header.
 *
 *   POST   /api/users         Create student record (public - Register form)
 *   POST   /api/users/login   Authenticate a student (public - Login form)
 *   GET    /api/users/me      Current authenticated student's own profile
 *   GET    /api/users         View all student records   (protected)
 *   GET    /api/users/:id     View one student record     (protected)
 *   PUT    /api/users/:id     Update student information   (protected)
 *   DELETE /api/users/:id     Delete student record         (protected)
 */
const router = Router();

// --- Public ---
router.post('/', asyncHandler(createUser));
router.post('/login', asyncHandler(loginUser));

// --- Protected (requires a valid JWT) ---
router.get('/me', protect, asyncHandler(getMe));
router.get('/', protect, asyncHandler(getUsers));
router
  .route('/:id')
  .get(protect, asyncHandler(getUserById))
  .put(protect, asyncHandler(updateUser))
  .delete(protect, asyncHandler(deleteUser));

export default router;
