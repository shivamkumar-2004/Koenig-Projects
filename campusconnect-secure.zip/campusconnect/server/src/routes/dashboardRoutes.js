import { Router } from 'express';
import asyncHandler from '../utils/asyncHandler.js';
import { protect } from '../middleware/auth.js';
import { getDashboardSummary } from '../controllers/dashboardController.js';

/**
 * GET /api/dashboard/summary  (protected)
 * Aggregated counts built with the array-method utilities in
 * utils/dataUtils.js (TODO 14).
 */
const router = Router();

router.get('/summary', protect, asyncHandler(getDashboardSummary));

export default router;
