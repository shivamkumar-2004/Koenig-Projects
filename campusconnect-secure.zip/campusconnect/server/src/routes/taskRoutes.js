import { Router } from 'express';
import asyncHandler from '../utils/asyncHandler.js';
import { protect } from '../middleware/auth.js';
import {
  createTask,
  getTasks,
  getTaskById,
  updateTask,
  deleteTask,
} from '../controllers/taskController.js';

/**
 * TODO 3/6: Task resource, fully behind authentication.
 *   POST   /api/tasks       Create task
 *   GET    /api/tasks       View all tasks (supports ?status, ?assignedUser, ?from, ?to)
 *   GET    /api/tasks/:id   View one task
 *   PUT    /api/tasks/:id   Update task status/details
 *   DELETE /api/tasks/:id   Delete task
 */
const router = Router();

router.use(protect); // every task route requires a logged-in student

router.route('/').post(asyncHandler(createTask)).get(asyncHandler(getTasks));
router
  .route('/:id')
  .get(asyncHandler(getTaskById))
  .put(asyncHandler(updateTask))
  .delete(asyncHandler(deleteTask));

export default router;
