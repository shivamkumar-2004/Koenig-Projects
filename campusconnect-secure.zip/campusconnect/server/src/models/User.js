import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

/** @typedef {import('../types.js').User} User */

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export const USER_ROLES = ['student', 'faculty', 'admin'];

/**
 * TODO 9: Refactor Data Structures - User.
 * Fields are grouped exactly as documented in src/types.js:
 *   - Identity:        name, email
 *   - Authentication:  password (hashed, hidden), role
 *   - Profile/audit:   createdAt, updatedAt (via schema `timestamps`)
 */
const userSchema = new mongoose.Schema(
  {
    // --- Identity ---
    name: {
      type: String,
      required: [true, 'Name is required.'],
      trim: true,
      minlength: [2, 'Name must be at least 2 characters.'],
      maxlength: [80, 'Name cannot exceed 80 characters.'],
    },
    email: {
      type: String,
      required: [true, 'Email is required.'],
      trim: true,
      lowercase: true,
      unique: true,
      match: [EMAIL_PATTERN, 'Enter a valid email address.'],
    },

    // --- Authentication ---
    password: {
      type: String,
      required: [true, 'Password is required.'],
      minlength: [8, 'Password must be at least 8 characters.'],
      select: false, // TODO 3: never returned by default queries
    },

    // --- Authorization (TODO 7: role-based access design) ---
    role: {
      type: String,
      enum: {
        values: USER_ROLES,
        message: `Role must be one of: ${USER_ROLES.join(', ')}.`,
      },
      default: 'student',
    },
  },
  { timestamps: true } // adds createdAt / updatedAt consistently across models
);

// TODO 3: Implement Password Security - hash on every create/change, never store plain text.
userSchema.pre('save', async function hashPassword(next) {
  if (!this.isModified('password')) return next();
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (err) {
    next(err);
  }
});

/**
 * TODO 3/4: compare a plaintext candidate against the stored hash.
 * @param {string} candidate
 * @returns {Promise<boolean>}
 */
userSchema.methods.comparePassword = function comparePassword(candidate) {
  return bcrypt.compare(candidate, this.password);
};

// Never leak the password hash or __v when a document is serialized to JSON.
userSchema.set('toJSON', {
  transform: (_doc, ret) => {
    delete ret.password;
    delete ret.__v;
    return ret;
  },
});

const User = mongoose.model('User', userSchema);

export default User;
