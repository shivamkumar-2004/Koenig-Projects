import mongoose from 'mongoose';

/** @typedef {import('../types.js').Task} Task */

export const TASK_STATUSES = ['pending', 'in-progress', 'completed'];

/**
 * TODO 9: Refactor Data Structures - Task.
 * Fields are grouped exactly as documented in src/types.js:
 *   - Task information: title, description
 *   - Status:           status
 *   - Ownership:         assignedUser (ref -> User)
 *   - Timestamps:        createdAt, updatedAt (via schema `timestamps`)
 */
const taskSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Task title is required.'],
      trim: true,
      minlength: [3, 'Title must be at least 3 characters.'],
      maxlength: [120, 'Title cannot exceed 120 characters.'],
    },
    description: {
      type: String,
      trim: true,
      maxlength: [500, 'Description cannot exceed 500 characters.'],
      default: '',
    },
    status: {
      type: String,
      enum: {
        values: TASK_STATUSES,
        message: `Status must be one of: ${TASK_STATUSES.join(', ')}.`,
      },
      default: 'pending',
    },
    assignedUser: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true }
);

taskSchema.set('toJSON', {
  transform: (_doc, ret) => {
    delete ret.__v;
    return ret;
  },
});

const Task = mongoose.model('Task', taskSchema);

export default Task;
