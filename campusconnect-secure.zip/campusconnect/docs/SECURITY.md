# Security Audit & Verification

## TODO 1: Authentication Gaps Found in the Pilot

| Gap | Where | Risk |
|---|---|---|
| **Unprotected dashboard APIs** | `GET /api/users`, `GET/PUT/DELETE /api/tasks` had no auth check at all | Anyone with the API's URL could read or modify every student's data and every task without ever logging in. |
| **Plain-text-adjacent password handling** | Passwords were hashed with bcrypt on write, but there was no login endpoint issuing any credential the client could later present, so there was no way to *prove* a request came from a logged-in user | Even though passwords were hashed at rest, the API had no concept of "this request is authenticated," which is the actual vulnerability the pilot testers hit. |
| **No token/session concept** | No JWT (or any token) existed anywhere in the app | Impossible to distinguish an authenticated request from an anonymous one. |
| **No role concept** | `User` model had no `role` field | No way to eventually restrict admin-only actions (delete any account, etc.). |
| **Inconsistent data shapes** | `registrationDate` vs `createdDate`, no shared definition of a "User" or "Task" across files | Increases the chance two developers build against slightly different assumptions about what fields exist. |

## Fixes Applied

- **`middleware/auth.js` (`protect`)** now guards every dashboard-related
  route (`/api/users` except register/login, all of `/api/tasks`, and
  `/api/dashboard/summary`). Requests without a valid
  `Authorization: Bearer <token>` header are rejected with `401` before
  touching the database or a controller.
- **`POST /api/users/login`** now verifies the bcrypt hash and, on success,
  issues a signed JWT (`utils/generateToken.js`) containing only the user's
  id and role - never the password hash.
- **`User.role`** (`student | faculty | admin`) plus the `authorize(...roles)`
  middleware lay the groundwork described in `docs/ROLES.md`.
- **`types.js`** gives every file one shared definition of `User`/`Task`/
  `ApiResponse` (checked with `npm run typecheck`), so "what fields does a
  Task have" stops being tribal knowledge.

## TODO 8: Verification

These were run directly against the running server (see the commands below;
all returned the expected status/body):

| Scenario | Request | Expected | Result |
|---|---|---|---|
| Missing token | `GET /api/users` with no `Authorization` header | `401`, clear message | ✅ `401 {"success":false,"message":"Not authorized. Please log in and try again."}` |
| Invalid token | `GET /api/users` with `Authorization: Bearer garbage` | `401` | ✅ `401 {"success":false,"message":"Not authorized. Invalid authentication token."}` |
| Missing token on tasks | `GET /api/tasks` with no header | `401` | ✅ |
| Missing token on summary | `GET /api/dashboard/summary` with no header | `401` | ✅ |
| Health check unaffected | `GET /api/health` | `200`, no auth required | ✅ `200 {"status":"ok",...}` |
| Expired token | Any protected route, token past `JWT_EXPIRES_IN` | `401`, "session has expired" | Verified by code path in `middleware/auth.js` (`TokenExpiredError` branch); exercise it by setting `JWT_EXPIRES_IN=5s` locally and waiting. |
| Valid login | `POST /api/users/login` with correct credentials | `200`, returns `{ user, token }` | Verify locally once `MONGODB_URI` points at a real database - registration and login both create/verify a bcrypt hash and return a token (see `controllers/userController.js`). |
| Invalid login | `POST /api/users/login` with wrong password | `401`, "Invalid email or password." | Same code path as above - a non-matching `comparePassword` result and a missing user are handled identically so the API never reveals *which* field was wrong. |
| Duplicate registration | `POST /api/users` with an email that already exists | `409`, field-level error | Handled explicitly in `createUser` before the DB write, backed by the schema's unique index as a second guarantee. |

Manual re-run (from the `server/` directory, with the API running on
`:5000`):

```bash
curl -s http://localhost:5000/api/health
curl -s -w " [%{http_code}]\n" http://localhost:5000/api/users
curl -s -w " [%{http_code}]\n" -H "Authorization: Bearer garbage" http://localhost:5000/api/users
curl -s -w " [%{http_code}]\n" -X POST http://localhost:5000/api/users \
  -H "Content-Type: application/json" \
  -d '{"name":"Ava Patel","email":"ava@campus.edu","password":"supersecret"}'
curl -s -w " [%{http_code}]\n" -X POST http://localhost:5000/api/users/login \
  -H "Content-Type: application/json" \
  -d '{"email":"ava@campus.edu","password":"supersecret"}'
```
