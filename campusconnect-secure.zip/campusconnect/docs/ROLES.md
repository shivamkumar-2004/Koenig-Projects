# Role-Based Access Control (RBAC) Design

**TODO 7: Prepare Role-Based Access Design.**

This is the access-control model CampusConnect is being built toward. Today,
every registered account gets the `student` role and every protected route
only checks *"is this a logged-in user?"* (via the `protect` middleware).
The `authorize(...roles)` middleware in `server/src/middleware/auth.js`
already exists and is ready to drop onto any route
(`router.delete('/:id', protect, authorize('admin'), deleteUser)`) once the
university decides which actions should be role-restricted.

## Roles

### Student (default role for every self-registered account)
- Log in and view their own profile.
- View the shared student directory and task board (current pilot behavior).
- Create tasks, and edit/complete their own tasks.
- Search students and filter tasks.

### Faculty
Everything a Student can do, plus:
- Create tasks and assign them to any student (not just themselves).
- View task completion status across all students they oversee.
- *Not* able to delete other users' accounts or change roles.

### Administrator
Everything a Faculty member can do, plus:
- Create, edit, and delete any user account, including changing a user's role.
- Delete any task regardless of owner.
- Access future account-management and reporting endpoints.

## How this maps to the codebase

| Concern                         | Mechanism                                                        |
|----------------------------------|--------------------------------------------------------------------|
| "Is there a logged-in user?"     | `protect` middleware (verifies the JWT, loads `req.user`)          |
| "Is this user allowed to do X?"  | `authorize('faculty', 'admin')` middleware (checks `req.user.role`) |
| Where a user's role lives        | `User.role` field: `'student' \| 'faculty' \| 'admin'`             |
| Assigning non-default roles      | Not yet exposed publicly - `role` defaults to `'student'` on
  self-registration. Promoting a user to `faculty`/`admin` will be a
  future admin-only endpoint (`PUT /api/users/:id/role`, `authorize('admin')`). |

## Rollout plan

1. Ship the current pilot as-is: all authenticated users share the same
   permissions (this lab's scope).
2. Add a `PUT /api/users/:id/role` endpoint restricted to `authorize('admin')`.
3. Seed the first administrator account directly in the database (never
   through the public registration endpoint).
4. Progressively tighten specific routes (e.g. `DELETE /api/users/:id`) to
   `authorize('admin')` once there's a real admin workflow to support it,
   rather than locking students out of features they currently rely on.
