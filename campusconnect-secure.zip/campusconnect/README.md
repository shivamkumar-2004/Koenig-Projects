# CampusConnect

A student activity management portal built on the MERN stack (MongoDB, Express, React, Node.js). This is the Phase 3 deliverable: secure, token-based authentication now protects the dashboard, user/task data structures are standardized, and the dashboard supports searching students and filtering tasks - on top of the full-stack CRUD app from Phase 2.

## Project structure

```
campusconnect/
├── client/                        React front-end (Vite)
│   └── src/
│       ├── components/
│       │   ├── layout/            Header (auth-aware nav + logout), Footer, Layout shell
│       │   ├── common/            Button, Card, FormInput, Alert
│       │   ├── auth/              ProtectedRoute - redirects to /login if not authenticated
│       │   └── dashboard/         StudentList (+search), TaskBoard (+filters)
│       ├── pages/                 Home, Login, Register, Dashboard, NotFound
│       ├── data/                  Mock announcement data (front-end only, no backend model)
│       ├── utils/
│       │   ├── validation.js      Client-side form validation
│       │   ├── api.js             Fetch wrapper - attaches JWT, handles 401s, search/filter params
│       │   └── auth.js            Session (user + JWT) storage in localStorage
│       ├── App.jsx, main.jsx, index.css
│       └── .env.example           VITE_API_BASE_URL
├── server/                        Node/Express + MongoDB API
│   ├── src/
│   │   ├── config/db.js           Mongoose connection
│   │   ├── models/                User.js (identity/auth/role), Task.js (info/status/ownership)
│   │   ├── controllers/           userController, taskController, dashboardController
│   │   ├── routes/                userRoutes, taskRoutes, dashboardRoutes
│   │   ├── middleware/            logger.js, errorHandler.js, auth.js (protect + authorize)
│   │   ├── utils/                 asyncHandler.js, generateToken.js, dataUtils.js (search/filter/DSA)
│   │   ├── types.js               Shared JSDoc typedefs (User, Task, ApiResponse, AuthPayload)
│   │   └── server.js              App entry point
│   ├── tsconfig.json               Enables `npm run typecheck` against the JSDoc typedefs
│   └── .env.example               PORT, MONGODB_URI, CLIENT_URL, JWT_SECRET, JWT_EXPIRES_IN
├── docs/
│   ├── ROLES.md                   Role-based access control design (student/faculty/admin)
│   ├── SECURITY.md                Security audit + verification test results
│   └── ARCHITECTURE.md
└── assets/                        Shared static assets (logos, icons, images)
```

## Getting started

### 1. Server

```bash
cd server
cp .env.example .env
# edit .env and set:
#   MONGODB_URI  - e.g. mongodb://localhost:27017/campusconnect, or a MongoDB Atlas URI
#   JWT_SECRET   - any long random string (e.g. `openssl rand -hex 32`)
npm install
npm run dev
```

The API listens on `http://localhost:5000`. If `MONGODB_URI` isn't set or the database is unreachable, the server still starts (so `/api/health` responds) but every route that touches the database returns a clear `503` error until it's fixed. If `JWT_SECRET` isn't set, the server logs a warning and login will fail until it's configured.

Run `npm run typecheck` any time to check the codebase against the shared JSDoc type definitions in `src/types.js` (no build step, nothing is emitted).

### 2. Client

```bash
cd client
cp .env.example .env   # VITE_API_BASE_URL defaults to http://localhost:5000/api
npm install
npm run dev
```

The dev server runs at `http://localhost:5173`.

## API reference

All routes are prefixed with `/api`. Protected routes require
`Authorization: Bearer <token>`, obtained from `POST /api/users/login`.

| Method | Endpoint                | Auth?      | Description                                        |
|--------|--------------------------|------------|-----------------------------------------------------|
| GET    | `/health`                | Public     | Service status check                                |
| POST   | `/users`                 | Public     | Register a student                                  |
| POST   | `/users/login`           | Public     | Authenticate a student, returns `{ user, token }`   |
| GET    | `/users/me`              | Protected  | Current authenticated student's own profile         |
| GET    | `/users?search=`         | Protected  | List/search students by name or email               |
| GET    | `/users/:id`             | Protected  | Get one student                                     |
| PUT    | `/users/:id`             | Protected  | Update a student's name/email/password              |
| DELETE | `/users/:id`             | Protected  | Delete a student                                    |
| POST   | `/tasks`                 | Protected  | Create a task                                       |
| GET    | `/tasks?status=&assignedUser=&from=&to=` | Protected | List/filter tasks (with assigned student populated) |
| GET    | `/tasks/:id`             | Protected  | Get one task                                        |
| PUT    | `/tasks/:id`             | Protected  | Update a task's details/status                      |
| DELETE | `/tasks/:id`             | Protected  | Delete a task                                       |
| GET    | `/dashboard/summary`     | Protected  | Aggregated counts (totals, by status, by student)   |

Every response follows `{ success, data?, message?, errors? }`. Validation errors return `400` with a per-field `errors` map; a missing record returns `404`; a duplicate email returns `409`; a missing/invalid/expired token returns `401`.

## What's implemented

- **Authentication** – registration hashes passwords with bcrypt; login verifies the hash and issues a signed JWT (`server/src/utils/generateToken.js`). The client stores `{ user, token }` (`client/src/utils/auth.js`) and attaches the token to every API call automatically.
- **Authorization** – `middleware/auth.js`'s `protect` guards every dashboard-related route (`/api/users` except register/login, all of `/api/tasks`, `/api/dashboard/summary`); missing/invalid/expired tokens are rejected with a clear `401` before touching a controller or the database. An `authorize(...roles)` helper and a `role` field on `User` (`student | faculty | admin`) lay the groundwork documented in `docs/ROLES.md`.
- **Client-side route protection** – `ProtectedRoute` redirects to `/login` if there's no valid session, and a `401` from any API call clears the stale session and bounces back to `/login`.
- **Standardized data structures** – `User` and `Task` both use Mongoose's `{ timestamps: true }` for consistent `createdAt`/`updatedAt` fields; every file shares one definition of what a `User`/`Task`/`ApiResponse` looks like via JSDoc typedefs in `server/src/types.js`, checked with `npm run typecheck` (TypeScript's `checkJs`, no build step required).
- **Search & filtering** – the dashboard's student list has a debounced search box (name/email); the task board has status/assigned-student/date-range filters. Both call the server (`GET /api/users?search=`, `GET /api/tasks?status=&assignedUser=&from=&to=`).
- **DSA-focused data utilities** (`server/src/utils/dataUtils.js`) – `findStudent`, `searchStudents`, `getIncompleteTasks`, `countCompletedTasks`, `groupTasksByStatus`, `groupTasksByOwner`, and `buildDashboardSummary`, each picking the array method (`find`/`filter`/`reduce`/`map`) that fits the job, backing the new `/api/dashboard/summary` endpoint.
- **Stronger error handling** – centralized handler covers validation errors, duplicate keys, bad ObjectIds, JWT errors, and a disconnected database, each with a distinct status code and message.
- **Full CRUD** – both resources still support create, read, update, and delete, backed directly by MongoDB, now behind auth.
- **Responsive layout** – carried over from earlier phases, extended to the new search/filter controls and nav.

## Known limitations

- Announcements remain front-end mock data — no `Announcement` model was requested for this lab, so that section is unchanged from Phase 1.
- Role-based *authorization* is designed and ready (`authorize()` middleware, `User.role`) but not yet enforced on any route - every authenticated user currently has the same permissions, matching this lab's stated scope ("future support for multiple user roles"). See `docs/ROLES.md` for the intended rollout.
- There's no refresh-token flow; when a JWT expires (`JWT_EXPIRES_IN`, default `1d`) the user is simply asked to log in again.
- Search and filtering are re-fetched from the server rather than computed purely client-side, so they need the backend running to work (by design - it's real, DB-backed search, not a demo over a hardcoded array).
