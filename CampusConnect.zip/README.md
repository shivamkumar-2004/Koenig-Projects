# CampusConnect — Student Activity Management Portal

A MERN-stack web app that lets students register, log in, reach a personal
dashboard, and read campus announcements. This is the **Phase 1–4 front-end
build**: React UI, routing, forms, and state — structured so a real Express +
MongoDB API can be dropped into `server/` later without touching the client.

## Folder structure

```
CampusConnect/
├── client/           React app (Vite)
│   └── src/
│       ├── components/   Reusable UI: Navbar, Footer, Layout, Button, Card, FormInput
│       ├── pages/         Home, Login, Register, Dashboard
│       └── data/          Mock announcements (stand-in for the future API)
├── server/           Node/Express skeleton, ready for real routes + MongoDB models
├── docs/             Shared documentation
└── assets/           Static assets shared across the project
```

## Running the client

```bash
cd client
npm install
npm run dev
```

Opens at `http://localhost:5173`. Pages: `/`, `/login`, `/register`, `/dashboard`.

## Running the server (skeleton)

```bash
cd server
npm install
npm run dev
```

Starts an Express server on port 5000 with one placeholder route
(`GET /api/health`) and empty `routes/` / `controllers/` / `models/` folders
ready for the real auth and announcements endpoints.

## What's implemented

- **Routing** — React Router, client-side navigation with no page reloads.
- **Forms** — Registration and login use controlled components (`useState`),
  with validation (required fields, email format, password rules, password
  confirmation match) and inline error/success messages.
- **Reusable components** — `Navbar`, `Footer`, `Layout`, `Button`, `Card`,
  `FormInput`, used across every page.
- **Conditional rendering** — validation errors, a submitting/loading state,
  and a success state on both forms.
- **Dynamic rendering** — the Dashboard reads a mock announcements array
  (`data/announcements.js`), each with a unique `id`, and maps it to cards.
- **Responsive layout** — a single CSS file with breakpoints; the nav
  collapses to a stacked menu on narrow screens.

## Wiring up the real backend later

`client/src/pages/Login.jsx` and `Register.jsx` currently simulate a network
call with `setTimeout`. Swap that block for a `fetch('/api/auth/...')` call
once the corresponding Express route exists in `server/routes/`.
