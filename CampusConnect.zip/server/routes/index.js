import { Router } from 'express';

const router = Router();

router.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'campusconnect-api' });
});

// TODO: mount real routes once controllers + MongoDB models are built:
// router.use('/auth', authRoutes);
// router.use('/announcements', announcementRoutes);

export default router;
