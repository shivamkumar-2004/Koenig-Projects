import express from 'express';
import cors from 'cors';
import 'dotenv/config';
import apiRoutes from './routes/index.js';

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.use('/api', apiRoutes);

app.listen(PORT, () => {
  console.log(`CampusConnect API listening on port ${PORT}`);
});
