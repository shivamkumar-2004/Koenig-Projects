import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import FormInput from '../components/FormInput.jsx';
import Button from '../components/Button.jsx';

function validate(values) {
  const errors = {};
  if (!values.email.trim()) errors.email = 'Email is required.';
  if (!values.password) errors.password = 'Password is required.';
  return errors;
}

export default function Login() {
  const navigate = useNavigate();
  const [values, setValues] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle');

  function handleChange(event) {
    const { name, value } = event.target;
    setValues((prev) => ({ ...prev, [name]: value }));
  }

  function handleSubmit(event) {
    event.preventDefault();
    const validationErrors = validate(values);
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) {
      setStatus('error');
      return;
    }

    setStatus('submitting');

    // Placeholder for POST /api/auth/login once the backend exists.
    setTimeout(() => {
      setStatus('success');
      setTimeout(() => navigate('/dashboard'), 800);
    }, 600);
  }

  return (
    <div className="form-page">
      <h1>Log in</h1>
      <p>Enter your credentials to reach your dashboard.</p>

      {status === 'error' && (
        <div className="form-banner error">Check the fields below and try again.</div>
      )}
      {status === 'success' && (
        <div className="form-banner success">Logged in — taking you to your dashboard…</div>
      )}

      <form onSubmit={handleSubmit} noValidate>
        <FormInput
          label="Email"
          type="email"
          name="email"
          value={values.email}
          onChange={handleChange}
          error={errors.email}
          placeholder="you@university.edu"
        />
        <FormInput
          label="Password"
          type="password"
          name="password"
          value={values.password}
          onChange={handleChange}
          error={errors.password}
        />

        <Button type="submit" disabled={status === 'submitting'}>
          {status === 'submitting' ? 'Logging in…' : 'Log in'}
        </Button>
      </form>

      <p className="form-footer-link">
        New here? <Link to="/register">Create an account</Link>
      </p>
    </div>
  );
}
