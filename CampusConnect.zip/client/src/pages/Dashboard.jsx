import { useEffect, useState } from 'react';
import Card from '../components/Card.jsx';
import announcementsData from '../data/announcements.js';

function formatDate(isoDate) {
  return new Date(isoDate).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export default function Dashboard() {
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Placeholder for GET /api/announcements once the backend exists.
    const timer = setTimeout(() => {
      setAnnouncements(announcementsData);
      setLoading(false);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div>
      <div className="dashboard-header">
        <h1>Your dashboard</h1>
        <span>Welcome back, Student</span>
      </div>

      <h2>Campus announcements</h2>

      {loading && <p className="loading-row">Loading announcements…</p>}

      {!loading && announcements.length === 0 && (
        <p>No announcements right now — check back later.</p>
      )}

      {!loading && announcements.length > 0 && (
        <div className="announcement-list">
          {announcements.map((item) => (
            <Card key={item.id} title={item.title} tag={item.category} meta={formatDate(item.date)}>
              <p>{item.body}</p>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
