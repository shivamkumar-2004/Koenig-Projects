import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import FormInput from '../components/FormInput.jsx';
import Button from '../components/Button.jsx';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate(values) {
  const errors = {};

  if (!values.name.trim()) {
    errors.name = 'Name is required.';
  }

  if (!values.email.trim()) {
    errors.email = 'Email is required.';
  } else if (!EMAIL_PATTERN.test(values.email)) {
    errors.email = 'Enter a valid email address.';
  }

  if (!values.password) {
    errors.password = 'Password is required.';
  } else if (values.password.length < 8) {
    errors.password = 'Password must be at least 8 characters.';
  } else if (!/[0-9]/.test(values.password) || !/[A-Za-z]/.test(values.password)) {
    errors.password = 'Password must include both letters and numbers.';
  }

  if (!values.confirmPassword) {
    errors.confirmPassword = 'Please confirm your password.';
  } else if (values.confirmPassword !== values.password) {
    errors.confirmPassword = 'Passwords do not match.';
  }

  return errors;
}

export default function Register() {
  const navigate = useNavigate();
  const [values, setValues] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle'); // idle | submitting | success | error

  function handleChange(event) {
    const { name, value } = event.target;
    setValues((prev) => ({ ...prev, [name]: value }));
  }

  function handleSubmit(event) {
    event.preventDefault();
    const validationErrors = validate(values);
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) {
      setStatus('error');
      return;
    }

    setStatus('submitting');

    // Placeholder for POST /api/auth/register once the backend exists.
    setTimeout(() => {
      setStatus('success');
      setTimeout(() => navigate('/login'), 1200);
    }, 700);
  }

  return (
    <div className="form-page">
      <h1>Create your account</h1>
      <p>Register with your university email to access the student dashboard.</p>

      {status === 'error' && (
        <div className="form-banner error">Please fix the errors below and try again.</div>
      )}
      {status === 'success' && (
        <div className="form-banner success">Account created — redirecting to login…</div>
      )}

      <form onSubmit={handleSubmit} noValidate>
        <FormInput
          label="Full name"
          name="name"
          value={values.name}
          onChange={handleChange}
          error={errors.name}
          placeholder="Shivam Kumar"
        />
        <FormInput
          label="Email"
          type="email"
          name="email"
          value={values.email}
          onChange={handleChange}
          error={errors.email}
          placeholder="you@university.edu"
        />
        <FormInput
          label="Password"
          type="password"
          name="password"
          value={values.password}
          onChange={handleChange}
          error={errors.password}
          placeholder="At least 8 characters, letters and numbers"
        />
        <FormInput
          label="Confirm password"
          type="password"
          name="confirmPassword"
          value={values.confirmPassword}
          onChange={handleChange}
          error={errors.confirmPassword}
        />

        <Button type="submit" disabled={status === 'submitting'}>
          {status === 'submitting' ? 'Creating account…' : 'Register'}
        </Button>
      </form>

      <p className="form-footer-link">
        Already have an account? <Link to="/login">Log in</Link>
      </p>
    </div>
  );
}
