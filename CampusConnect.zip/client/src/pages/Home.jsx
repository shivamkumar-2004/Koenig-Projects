import { Link } from 'react-router-dom';
import Card from '../components/Card.jsx';
import Button from '../components/Button.jsx';

const features = [
  {
    title: 'One dashboard',
    body: 'Everything a student needs after logging in — announcements, activity, and account details in one place.',
  },
  {
    title: 'Campus announcements',
    body: 'Academic, event, and placement notices, published as soon as departments post them.',
  },
  {
    title: 'Built to grow',
    body: 'The front end is ready for a real MongoDB-backed API — no rewrite needed when the backend lands.',
  },
];

export default function Home() {
  return (
    <div>
      <section className="hero">
        <p className="kicker">Student Activity Management Portal</p>
        <h1>Register, log in, and keep up with your campus in one place.</h1>
        <p>
          CampusConnect brings registration, login, and university announcements
          together so you're not checking five different noticeboards for one
          exam schedule.
        </p>
        <div className="hero-actions">
          <Link to="/register">
            <Button variant="primary">Create an account</Button>
          </Link>
          <Link to="/login">
            <Button variant="secondary">Log in</Button>
          </Link>
        </div>
      </section>

      <div className="feature-grid">
        {features.map((f) => (
          <Card key={f.title} title={f.title}>
            <p>{f.body}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
