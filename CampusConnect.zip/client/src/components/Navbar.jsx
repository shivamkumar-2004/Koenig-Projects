import { useState } from 'react';
import { NavLink } from 'react-router-dom';

export default function Navbar() {
  const [open, setOpen] = useState(false);

  const linkClass = ({ isActive }) => (isActive ? 'active' : undefined);

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <NavLink to="/" className="brand">
          Campus<span>Connect</span>
        </NavLink>

        <button
          className="nav-toggle"
          aria-label="Toggle navigation menu"
          aria-expanded={open}
          onClick={() => setOpen((prev) => !prev)}
        >
          Menu
        </button>

        <ul className={`nav-links${open ? ' open' : ''}`}>
          <li>
            <NavLink to="/" className={linkClass} onClick={() => setOpen(false)} end>
              Home
            </NavLink>
          </li>
          <li>
            <NavLink to="/login" className={linkClass} onClick={() => setOpen(false)}>
              Login
            </NavLink>
          </li>
          <li>
            <NavLink to="/register" className={linkClass} onClick={() => setOpen(false)}>
              Register
            </NavLink>
          </li>
          <li>
            <NavLink to="/dashboard" className={linkClass} onClick={() => setOpen(false)}>
              Dashboard
            </NavLink>
          </li>
        </ul>
      </div>
    </header>
  );
}
