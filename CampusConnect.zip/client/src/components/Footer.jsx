export default function Footer() {
  return (
    <footer className="footer">
      <p style={{ margin: 0, maxWidth: 'none' }}>
        CampusConnect — Student Activity Management Portal · Built for the MERN full-stack lab
      </p>
    </footer>
  );
}
