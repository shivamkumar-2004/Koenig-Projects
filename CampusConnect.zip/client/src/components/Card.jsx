export default function Card({ title, meta, tag, children }) {
  return (
    <article className="card">
      {(meta || tag) && (
        <div className="meta">
          {tag && <span className="tag">{tag}</span>}
          {tag && meta && ' · '}
          {meta}
        </div>
      )}
      {title && <h3>{title}</h3>}
      {children}
    </article>
  );
}
