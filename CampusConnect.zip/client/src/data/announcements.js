// Stand-in for GET /api/announcements. Swap for a fetch() call once the
// Express route + MongoDB model exist in server/.
const announcements = [
  {
    id: 'ann-001',
    title: 'Mid-semester exam schedule released',
    category: 'Academics',
    date: '2026-09-10',
    body: 'The examination cell has posted the mid-semester timetable for all branches. Check your department noticeboard for room allocations.',
  },
  {
    id: 'ann-002',
    title: 'Annual Tech Fest — registrations open',
    category: 'Events',
    date: '2026-09-08',
    body: 'Team registrations for the coding, robotics, and design tracks are open until the end of the month. Team size: 2–4 students.',
  },
  {
    id: 'ann-003',
    title: 'Library extended hours during exams',
    category: 'Facilities',
    date: '2026-09-05',
    body: 'The central library will stay open until midnight starting next week to support exam preparation.',
  },
  {
    id: 'ann-004',
    title: 'Placement drive: pre-placement talk',
    category: 'Placements',
    date: '2026-09-02',
    body: 'A pre-placement talk for final-year students is scheduled in the main auditorium. Attendance is mandatory for interested candidates.',
  },
];

export default announcements;
