import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      // Once the Express server is running, uncomment to forward API calls:
      // '/api': 'http://localhost:5000',
    },
  },
});
