# CampusConnect — Project Notes

## Scope covered in this build
- Phase 1: MERN folder structure (client / server / docs / assets), client and
  server initialized independently.
- Phase 2: Home, Login, Register, Dashboard pages; reusable Navbar, Footer,
  Layout, Button, Card, FormInput components; responsive styling.
- Phase 3: Controlled forms with validation, event handling for submit/click/
  change/navigation, conditional rendering (errors, success, loading), mock
  announcements rendered dynamically with unique ids.
- Phase 4: React Router navigation with no full-page reloads, a shared Layout
  used by every page, full validation rules for registration and login.

## Deferred to the real backend build
- Persisting users (MongoDB `User` model, `server/models/`).
- Real auth endpoints (`server/routes/auth.js`, `server/controllers/authController.js`),
  password hashing, session/JWT handling.
- Real announcements endpoint backed by a MongoDB collection instead of
  `client/src/data/announcements.js`.
- Protecting `/dashboard` behind an authenticated session once login is real.
