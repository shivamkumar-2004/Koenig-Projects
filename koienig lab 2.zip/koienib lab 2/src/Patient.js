// Patient.js
// just a simple class to hold patient info, nothing fancy

class Patient {
  constructor(id, name, age, priority, arrivalTime, department) {
    this.id = id;
    this.name = name;
    this.age = age;
    this.priority = priority; // 1 = critical, 2 = urgent, 3 = routine
    this.arrivalTime = arrivalTime; // in minutes, just using a simple clock for the demo
    this.department = department;
  }

  toString() {
    const labels = { 1: "Critical", 2: "Urgent", 3: "Routine" };
    const p = labels[this.priority] || "Unknown";
    return `[ID:${this.id}] ${this.name} | Age:${this.age} | Priority:${p} | Arrived:${this.arrivalTime}min | Dept:${this.department}`;
  }
}

module.exports = Patient;
