// sorting.js
// bubble, selection, insertion, merge, quick sort
// key = which field to sort by ("id", "priority", "arrivalTime")

function cmp(key) {
  return (a, b) => a[key] - b[key];
}

function bubbleSort(arr, key) {
  const a = [...arr]; // don't mutate the original array
  const compare = cmp(key);
  const n = a.length;

  for (let i = 0; i < n - 1; i++) {
    let swapped = false;
    for (let j = 0; j < n - i - 1; j++) {
      if (compare(a[j], a[j + 1]) > 0) {
        // swap
        const temp = a[j];
        a[j] = a[j + 1];
        a[j + 1] = temp;
        swapped = true;
      }
    }
    if (!swapped) break; // already sorted, no point continuing
  }
  return a;
}

function selectionSort(arr, key) {
  const a = [...arr];
  const compare = cmp(key);

  for (let i = 0; i < a.length - 1; i++) {
    let minIdx = i;
    for (let j = i + 1; j < a.length; j++) {
      if (compare(a[j], a[minIdx]) < 0) minIdx = j;
    }
    if (minIdx !== i) {
      const temp = a[i];
      a[i] = a[minIdx];
      a[minIdx] = temp;
    }
  }
  return a;
}

function insertionSort(arr, key) {
  const a = [...arr];
  const compare = cmp(key);

  for (let i = 1; i < a.length; i++) {
    const current = a[i];
    let j = i - 1;
    while (j >= 0 && compare(a[j], current) > 0) {
      a[j + 1] = a[j];
      j--;
    }
    a[j + 1] = current;
  }
  return a;
}

// classic recursive merge sort
function mergeSort(arr, key) {
  if (arr.length <= 1) return [...arr];
  const compare = cmp(key);

  const mid = Math.floor(arr.length / 2);
  const left = mergeSort(arr.slice(0, mid), key);
  const right = mergeSort(arr.slice(mid), key);

  // merge step
  const result = [];
  let i = 0;
  let j = 0;
  while (i < left.length && j < right.length) {
    // using <= here keeps it stable (equal elements keep original order)
    if (compare(left[i], right[j]) <= 0) {
      result.push(left[i]);
      i++;
    } else {
      result.push(right[j]);
      j++;
    }
  }
  while (i < left.length) result.push(left[i++]);
  while (j < right.length) result.push(right[j++]);

  return result;
}

// quick sort, using last element as pivot (lomuto partition)
function quickSort(arr, key) {
  const a = [...arr];
  const compare = cmp(key);

  function partition(low, high) {
    const pivot = a[high];
    let i = low - 1;
    for (let j = low; j < high; j++) {
      if (compare(a[j], pivot) < 0) {
        i++;
        const t = a[i];
        a[i] = a[j];
        a[j] = t;
      }
    }
    const t = a[i + 1];
    a[i + 1] = a[high];
    a[high] = t;
    return i + 1;
  }

  function doSort(low, high) {
    if (low < high) {
      const p = partition(low, high);
      doSort(low, p - 1);
      doSort(p + 1, high);
    }
  }

  doSort(0, a.length - 1);
  return a;
}

module.exports = { bubbleSort, selectionSort, insertionSort, mergeSort, quickSort };

/*
  complexity (roughly, n = number of patients):
  bubble sort     - O(n^2) worst/avg, O(n) best case (already sorted), O(1) space, stable
  selection sort  - O(n^2) always, O(1) space, not stable
  insertion sort  - O(n^2) worst/avg, O(n) best, O(1) space, stable
  merge sort      - O(n log n) always, O(n) space (extra arrays), stable
  quick sort      - O(n log n) avg, O(n^2) worst (bad pivot choices), O(log n) space, not stable

  why merge/quick sort matter for a big hospital:
  the simple sorts are fine for like 10-20 records but if the hospital has
  thousands of old patient records, O(n^2) starts taking way too long.
  merge sort is nice because it's stable - so if two patients have the
  same priority it keeps them in arrival order, which matters for fairness.
  quick sort is usually faster in practice and doesn't need extra memory
  like merge sort does, but worst case can be bad if the data is already
  sorted or has a lot of duplicates (depends on pivot choice).
*/
