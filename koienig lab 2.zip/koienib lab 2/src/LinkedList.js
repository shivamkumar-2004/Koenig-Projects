// LinkedList.js
// singly linked list + doubly linked list for storing patients

// ---------------- Singly Linked List ----------------

class SNode {
  constructor(patient) {
    this.patient = patient;
    this.next = null;
  }
}

class SinglyLinkedList {
  constructor() {
    this.head = null;
    this.tail = null;
    this.size = 0;
  }

  insertAtEnd(patient) {
    const node = new SNode(patient);
    if (!this.head) {
      this.head = node;
      this.tail = node;
    } else {
      this.tail.next = node;
      this.tail = node;
    }
    this.size++;
    return node;
  }

  insertAtStart(patient) {
    const node = new SNode(patient);
    node.next = this.head;
    this.head = node;
    if (!this.tail) this.tail = node;
    this.size++;
    return node;
  }

  deleteById(id) {
    let curr = this.head;
    let prev = null;

    while (curr) {
      if (curr.patient.id === id) {
        if (prev) {
          prev.next = curr.next;
        } else {
          this.head = curr.next;
        }
        if (curr === this.tail) this.tail = prev;
        this.size--;
        return true;
      }
      prev = curr;
      curr = curr.next;
    }
    return false; // not found
  }

  findById(id) {
    let curr = this.head;
    while (curr) {
      if (curr.patient.id === id) return curr.patient;
      curr = curr.next;
    }
    return null;
  }

  traverse() {
    const out = [];
    let curr = this.head;
    while (curr) {
      out.push(curr.patient);
      curr = curr.next;
    }
    return out;
  }
}

// ---------------- Doubly Linked List ----------------
// same idea but each node also points back to the previous one
// so we can walk the list backwards too

class DNode {
  constructor(patient) {
    this.patient = patient;
    this.prev = null;
    this.next = null;
  }
}

class DoublyLinkedList {
  constructor() {
    this.head = null;
    this.tail = null;
    this.size = 0;
  }

  insertAtEnd(patient) {
    const node = new DNode(patient);
    if (!this.head) {
      this.head = node;
      this.tail = node;
    } else {
      node.prev = this.tail;
      this.tail.next = node;
      this.tail = node;
    }
    this.size++;
    return node;
  }

  insertAtStart(patient) {
    const node = new DNode(patient);
    if (!this.head) {
      this.head = node;
      this.tail = node;
    } else {
      node.next = this.head;
      this.head.prev = node;
      this.head = node;
    }
    this.size++;
    return node;
  }

  deleteById(id) {
    let curr = this.head;
    while (curr) {
      if (curr.patient.id === id) {
        if (curr.prev) curr.prev.next = curr.next;
        else this.head = curr.next;

        if (curr.next) curr.next.prev = curr.prev;
        else this.tail = curr.prev;

        this.size--;
        return true;
      }
      curr = curr.next;
    }
    return false;
  }

  traverseForward() {
    const out = [];
    let curr = this.head;
    while (curr) {
      out.push(curr.patient);
      curr = curr.next;
    }
    return out;
  }

  traverseBackward() {
    const out = [];
    let curr = this.tail;
    while (curr) {
      out.push(curr.patient);
      curr = curr.prev;
    }
    return out;
  }
}

module.exports = { SinglyLinkedList, DoublyLinkedList };

/*
  array vs linked list for the ED patient list:
  - array gives O(1) access by index but inserting/removing from the
    middle is O(n) because everything has to shift over
  - linked list is O(1) to insert/delete once you already have the node,
    no shifting needed, but you can't jump to index i directly, have to
    walk from the head - O(n)

  since patients get added/discharged/transferred all the time, a linked
  list makes more sense for the "live" list. array/hash table is better
  when you mostly just need to look things up by id fast.

  doubly linked list is basically the same thing but the extra prev
  pointer lets staff scroll backward through the list too (like reviewing
  older patients starting from the most recent one), and it makes
  deleting a node you already have a pointer to O(1) since you don't need
  to separately track the previous node.

  complexity: traverse O(n), insert at head/tail O(1), find by id O(n),
  delete by id O(n) to find + O(1) to unlink. space O(n).
*/
